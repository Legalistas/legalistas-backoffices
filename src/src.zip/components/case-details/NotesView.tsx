"use client"

import { useState } from "react"
import { Plus, User, Trash2 } from "lucide-react"
import Button from "@/components/ui/button/Button"
import { Card, CardContent, CardDescription, CardHeader } from "@/components/ui/card/Card"
import type { CasesNotes } from "@/types/cases"
import { CreateNoteForm } from "./CreateNoteForm"
import { formatDistanceToNow } from "@/utils/format"
import Image from "next/image"
import { useSession } from "next-auth/react"
import { CASES_NOTES_DELETE_ENDPOINT } from "@/constant/api-endpoints"

interface NotesViewProps {
  notes: CasesNotes[]
  caseId: string
  onNoteCreated: () => void
  onNoteDeleted?: (noteId: number) => void
}

export const NotesView = ({ notes, caseId, onNoteCreated, onNoteDeleted }: NotesViewProps) => {
  const { data: session } = useSession()
  const [isCreating, setIsCreating] = useState(false)
  const [deletingNoteId, setDeletingNoteId] = useState<number | null>(null)


  const handleCreateNote = () => {
    setIsCreating(true)
  }

  const handleCancelCreate = () => {
    setIsCreating(false)
  }

  const handleNoteCreated = () => {
    setIsCreating(false)
    onNoteCreated()
  }

  const handleDeleteNote = async (noteId: number) => {
    if (!confirm("¿Estás seguro de que quieres eliminar esta nota?")) return

    setDeletingNoteId(noteId)
    try {
      const response = await fetch(CASES_NOTES_DELETE_ENDPOINT(Number(caseId), noteId), {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${session?.user?.accessToken}`,
        },
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || "Error al eliminar la nota")
      }

      // Notificar al componente padre que la nota fue eliminada
      onNoteDeleted?.(noteId)
    } catch (error) {
      console.error("Error deleting note:", error)
      alert("No se pudo eliminar la nota. Por favor, intenta de nuevo.")
    } finally {
      setDeletingNoteId(null)
    }
  }

  if (isCreating) {
    return <CreateNoteForm caseId={caseId} onCancel={handleCancelCreate} onSuccess={handleNoteCreated} />
  }

  return (
    <div className="space-y-4 p-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Notas</h2>
        <Button onClick={handleCreateNote} size="sm">
          <Plus className="mr-2 h-4 w-4" />
          Nueva Nota
        </Button>
      </div>

      {notes.length === 0 ? (
        <div className="flex min-h-[200px] flex-col items-center justify-center rounded-lg border border-dashed border-gray-300 p-8 text-center">
          <p className="text-gray-500">No hay notas para este caso. Crea una nueva nota para comenzar.</p>
        </div>
      ) : (
        <div className="h-auto pr-4">
          <div className="space-y-4">
            {notes.map((note, index) => (
              <Card
                key={index}
                className="group hover:shadow-lg transition-all duration-300 border-0 shadow-sm bg-white overflow-hidden"
              >
                <CardHeader className="pb-4 bg-gradient-to-r from-gray-50 to-white">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-4">
                      {/* Avatar mejorado */}
                      <div className="relative">
                        <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg">
                          {note.user.image ? (
                            <Image
                              src={`${process.env.NEXT_PUBLIC_BACKEND_URL}${note.user.image}` || "/images/placeholder.svg"}
                              alt={note.user.name || "User Avatar"}
                              width={24}
                              height={24}
                              quality={100}
                              priority
                              className="h-full w-full object-cover rounded-full shadow-inner"
                            />
                          ) : (
                            <User className="h-6 w-6 text-white" />
                          )}
                        </div>
                        <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white"></div>
                      </div>

                      <div>
                        <p className="text-lg font-semibold text-gray-900">{note.user.name}</p>
                        <CardDescription className="text-sm text-gray-500 flex items-center">
                          <span className="w-1 h-1 bg-gray-400 rounded-full mr-2 inline-block"></span>
                          {formatDistanceToNow(new Date(note.createdAt))}
                        </CardDescription>
                      </div>
                    </div>

                    {/* Botón de eliminar mejorado */}
                    <button
                      onClick={() => handleDeleteNote(Number(note.id))}
                      disabled={deletingNoteId !== null && deletingNoteId === Number(note.id)}
                      className="opacity-0 group-hover:opacity-100 transition-all duration-200 p-2 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-600 disabled:opacity-50"
                    >
                      {deletingNoteId !== null && deletingNoteId === Number(note.id) ? (
                        <div className="w-5 h-5 border-2 border-red-600 border-t-transparent rounded-full animate-spin"></div>
                      ) : (
                        <Trash2 className="h-5 w-5" />
                      )}
                    </button>
                  </div>
                </CardHeader>

                <CardContent className="pt-2 pb-6">
                  {/* Contenido de la nota mejorado */}
                  <div className="text-gray-800 leading-relaxed whitespace-pre-wrap font-medium" dangerouslySetInnerHTML={{ __html: note.note }} />

                  {/* Footer de la nota */}
                  <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100">
                    <div className="flex items-center space-x-2 text-xs text-gray-500">
                      <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full">Nota #{index + 1}</span>
                    </div>
                    <div className="text-xs text-gray-400">ID: {note.id}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

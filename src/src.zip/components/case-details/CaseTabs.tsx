"use client"

import { useState } from "react"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs/Tabs"
import type { CaseLogs, CasesFiles, CasesNotes } from "@/types/cases"
import { EmptyFilesState } from "./EmptyFilesState"
import { FilesCardView } from "./FilesCardView"
import { FilesListView } from "./FilesListView"
import { NotesView } from "./NotesView"
import { EmptyNotesState } from "./EmptyNotesState"
import CaseLogsComponent from "./CaseLogsComponent"

interface CaseTabsProps {
  activeTab: string
  onTabChange: (tab: string) => void
  files: CasesFiles[]
  notes: CasesNotes[]
  logs: CaseLogs[]
  caseId: string
  viewMode: "card" | "list"
  fileTypeFilter: number
  filteredFiles: CasesFiles[]
  onAddNewFile: () => void
  onClearFilter: () => void
  onNotesUpdated?: () => void
  customer: {
    name: string
  }
}

export const CaseTabs = ({
  activeTab,
  onTabChange,
  files,
  notes = [],
  logs = [],
  caseId,
  viewMode,
  fileTypeFilter,
  filteredFiles,
  onAddNewFile,
  onClearFilter,
  customer,
  onNotesUpdated = () => { },
}: CaseTabsProps) => {
  const [isCreatingNote, setIsCreatingNote] = useState(false)

  const handleAddNewNote = () => {
    setIsCreatingNote(true)
  }

  const handleNoteCreated = () => {
    setIsCreatingNote(false)
    onNotesUpdated()
  }

  return (
    <Tabs defaultValue={activeTab} onValueChange={onTabChange} className="w-full">
      <TabsList className="w-full bg-white dark:bg-gray-800 text-gray-dark dark:text-gray-100 p-2">
        <TabsTrigger value="files">Expedientes</TabsTrigger>
        <TabsTrigger value="notes">Notas</TabsTrigger>
        <TabsTrigger value="documents">Documentos</TabsTrigger>
        <TabsTrigger value="record">Historial</TabsTrigger>
      </TabsList>

      <TabsContent value="files" className="bg-white dark:bg-gray-800 text-gray-dark dark:text-gray-100">
        {!files || files.length === 0 ? (
          <EmptyFilesState
            noFiles={true}
            fileTypeFilter={fileTypeFilter}
            onAddNewFile={onAddNewFile}
            onClearFilter={onClearFilter}
          />
        ) : filteredFiles.length === 0 ? (
          <EmptyFilesState
            noFiles={false}
            fileTypeFilter={fileTypeFilter}
            onAddNewFile={onAddNewFile}
            onClearFilter={onClearFilter}
          />
        ) : viewMode === "list" ? (
          <FilesListView files={filteredFiles} caseId={caseId} customer={customer} />
        ) : (
          <FilesCardView files={filteredFiles} caseId={caseId} customer={customer} />
        )}
      </TabsContent>

      <TabsContent value="notes" className="bg-white dark:bg-gray-800 text-gray-dark dark:text-gray-100">
        {isCreatingNote || (notes && notes.length > 0) ? (
          <NotesView notes={notes} caseId={caseId} onNoteCreated={handleNoteCreated} />
        ) : (
          <EmptyNotesState onAddNewNote={handleAddNewNote} />
        )}
      </TabsContent>


      <TabsContent value="documents" className="bg-white dark:bg-gray-800 text-gray-dark dark:text-gray-100">
        <div className="flex min-h-[200px] flex-col items-center justify-center rounded-lg border border-dashed border-gray-300 p-8 text-center">
          <p className="text-gray-500">Documents will be available soon.</p>
        </div>
      </TabsContent>

      <TabsContent value="record" className="bg-white dark:bg-gray-800 text-gray-dark dark:text-gray-100">
        <CaseLogsComponent logs={logs} />
      </TabsContent>
    </Tabs>
  )
}

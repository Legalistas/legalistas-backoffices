"use client"

import type React from "react"

import { useState } from "react"
import { ArrowLeft, Loader2 } from "lucide-react"
import Button from "@/components/ui/button/Button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card/Card"
import Textarea from "@/components/ui/input/TextArea"
import { useSession } from "next-auth/react"
import { CASES_NOTES_CREATE_ENDPOINT } from "@/constant/api-endpoints"

interface CreateNoteFormProps {
    caseId: string
    onCancel: () => void
    onSuccess: () => void
}

export const CreateNoteForm = ({ caseId, onCancel, onSuccess }: CreateNoteFormProps) => {
    const { data: session } = useSession()
    const [isSubmitting, setIsSubmitting] = useState(false)
    const [content, setContent] = useState("")
    const [error, setError] = useState("")


    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()

        if (!content.trim()) {
            setError("El contenido es requerido")
            return
        }

        setIsSubmitting(true)
        setError("")

        try {
            const response = await fetch(CASES_NOTES_CREATE_ENDPOINT(Number(caseId)), {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${session?.user?.accessToken}`,
                },
                body: JSON.stringify({
                    caseId: Number(caseId),
                    note: content.trim(),
                    userId: session?.user?.id,
                }),
            })

            if (!response.ok) {
                const errorData = await response.json()
                setError(errorData.message || "Error al crear la nota")
                return
            }

            // Éxito - limpiar formulario y notificar
            setContent("")
            onSuccess()
        } catch (error) {
            console.error("Error creating note:", error)
            setError("No se pudo crear la nota. Por favor, intenta de nuevo.")
        } finally {
            setIsSubmitting(false)
        }
    }

    return (
        <Card className="border-t-4 border-t-primary">
            <CardHeader>
                <div className="flex items-center">
                    <Button variant="outline" size="sm" onClick={onCancel} className="mr-2 p-0 h-8 w-8">
                        <ArrowLeft className="h-4 w-4" />
                        <span className="sr-only">Volver</span>
                    </Button>
                    <CardTitle>Nueva Nota</CardTitle>
                </div>
            </CardHeader>
            <form onSubmit={handleSubmit}>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <label
                            htmlFor="content"
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                            Contenido
                        </label>
                        <Textarea
                            placeholder="Escribe el contenido de la nota aquí..."
                            className="min-h-[200px]"
                            value={content}
                            onChange={setContent}
                        />
                        {error && <p className="text-sm font-medium text-destructive">{error}</p>}
                    </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                    <Button variant="outline" onClick={onCancel}>
                        Cancelar
                    </Button>
                    <Button disabled={isSubmitting}>
                        {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Guardar Nota
                    </Button>
                </CardFooter>
            </form>
        </Card>
    )
}

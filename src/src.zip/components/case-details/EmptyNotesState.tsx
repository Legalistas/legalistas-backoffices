"use client"

import { Plus } from "lucide-react"
import Button from "@/components/ui/button/Button"

interface EmptyNotesStateProps {
    onAddNewNote: () => void
}

export const EmptyNotesState = ({ onAddNewNote }: EmptyNotesStateProps) => {
    return (
        <div className="flex min-h-[300px] flex-col items-center justify-center rounded-lg border border-dashed border-gray-300 p-8 text-center">
            <h3 className="mb-2 text-lg font-medium">No hay notas</h3>
            <p className="mb-6 text-sm text-muted-foreground">
                No hay notas asociadas a este caso. Crea una nueva nota para comenzar a documentar información importante.
            </p>
            <Button onClick={onAddNewNote}>
                <Plus className="mr-2 h-4 w-4" />
                Nueva Nota
            </Button>
        </div>
    )
}

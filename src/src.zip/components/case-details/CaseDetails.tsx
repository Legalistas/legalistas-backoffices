"use client"

import { Calendar, Edit, FileText, Trash2, User, Briefcase, Scale, CheckCircle, XCircle, Clock } from "lucide-react"
import Image from "next/image"
import Badge from "@/components/ui/badge/Badge"
import Button from "@/components/ui/button/Button"
import { getServiceName, getStatusColor, getStatusName, getStatusLabel } from "@/lib/functions"
import type { Cases } from "@/types/cases"
import { statusType } from "@/lib/constant"
import { useState } from "react"

interface CaseDetailsProps {
    caseData: Cases
    onEdit: () => void
    onDelete: () => void
}

// Helper function to get status icon
const getStatusIcon = (status: string | undefined) => {
    switch (status) {
      case "WON":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "LOST":
        return <XCircle className="h-4 w-4 text-red-500" />
      case "IN_PROGRESS":
      default:
        return <Clock className="h-4 w-4 text-blue-500" />
    }
  }

export const CaseDetails = ({ caseData, onEdit, onDelete }: CaseDetailsProps) => {
    return (
        <div className="mb-8 overflow-hidden rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-sm">
            {/* Header section with case title and badges */}
            <div className="border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-gray-50 to-white dark:from-gray-800 dark:to-gray-750 px-6 py-5">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div className="flex-shrink-0">
                        <h2 className="text-xl font-semibold text-gray-900 dark:text-white">{caseData.title}</h2>
                        <div className="mt-2 flex items-center text-sm text-gray-500 dark:text-gray-400">
                            <Calendar className="mr-1.5 h-4 w-4 flex-shrink-0" />
                            <span>Creado el {new Date(caseData?.createdAt ?? "-").toLocaleDateString()}</span>
                        </div>
                    </div>

                    <div className="flex flex-col items-end gap-2 flex-shrink-0">
                        <Badge size="sm" color={getStatusColor(caseData?.stageId ?? "-")}>
                            {getStatusName(caseData?.stageId ?? "-")}
                        </Badge>
                        <div className="flex items-center">
                            <Briefcase className="mr-1.5 h-3.5 w-3.5 text-gray-500 dark:text-gray-400" />
                            <Badge size="sm" variant="light">
                                {getServiceName(caseData?.servicesId ?? "-")}
                            </Badge>
                        </div>
                    </div>
                </div>
            </div>

            {/* Case number and status section */}
            <div className="px-6 py-4 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="flex flex-col">
                        <span className="text-xs uppercase tracking-wider text-gray-500 dark:text-gray-400 font-medium">
                            Número de caso
                        </span>
                        <span className="mt-1 font-medium text-gray-900 dark:text-white">
                            {caseData.number ?? caseData.id ?? "Sin número"}
                        </span>
                    </div>
                    <div className="flex flex-col">
                        <span className="text-xs uppercase tracking-wider text-gray-500 dark:text-gray-400 font-medium">
                            Estado
                        </span>
                        <span className="mt-1 font-medium text-gray-900 dark:text-white flex items-center">
                            {getStatusIcon(caseData.status)}
                            <span className="ml-1.5">{getStatusLabel(caseData.status)}</span>
                        </span>
                    </div>
                    <div className="flex flex-col">
                        <span className="text-xs uppercase tracking-wider text-gray-500 dark:text-gray-400 font-medium">
                            Archivado
                        </span>
                        <span className="mt-1 font-medium text-gray-900 dark:text-white">{caseData.isArchived ? "Sí" : "No"}</span>
                    </div>
                </div>
            </div>

            {/* Lawyers section */}
            <div className="px-6 py-5 bg-white dark:bg-gray-800">
                <h3 className="text-base font-medium text-gray-900 dark:text-white mb-4">Abogados asignados</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Responsible Lawyer */}
                    <div className="bg-gray-50 dark:bg-gray-750 rounded-lg p-4 border border-gray-100 dark:border-gray-700">
                        <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3 flex items-center">
                            <User className="w-4 h-4 mr-1.5 text-blue-500" />
                            Abogado Responsable
                        </h4>
                        {caseData?.responsibleLawyer ? (
                            <div className="flex items-center gap-3">
                                {caseData?.responsibleLawyer?.image ? (
                                    <Image
                                        className="w-10 h-10 rounded-full ring-2 ring-white dark:ring-gray-700"
                                        src={process.env.NEXT_PUBLIC_BACKEND_URL + caseData?.responsibleLawyer?.image || "/placeholder.svg"}
                                        alt={`${caseData?.responsibleLawyer?.name || "Lawyer"} profile`}
                                        width={40}
                                        height={40}
                                    />
                                ) : (
                                    <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-blue-600 dark:text-blue-300 text-sm font-medium">
                                        {caseData?.responsibleLawyer?.name ? caseData.responsibleLawyer.name.charAt(0).toUpperCase() : "L"}
                                    </div>
                                )}
                                <div>
                                    <p className="text-sm font-medium text-gray-800 dark:text-gray-200">
                                        {caseData?.responsibleLawyer?.name || "Sin asignar"}
                                    </p>
                                    <p className="text-xs text-gray-500 dark:text-gray-400">{caseData?.responsibleLawyer?.email || ""}</p>
                                </div>
                            </div>
                        ) : (
                            <div className="flex items-center gap-3 text-gray-500 dark:text-gray-400">
                                <div className="w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center">
                                    <User className="w-5 h-5 text-gray-400 dark:text-gray-500" />
                                </div>
                                <span className="text-sm">Sin asignar</span>
                            </div>
                        )}
                    </div>

                    {/* Internal Lawyer */}
                    <div className="bg-gray-50 dark:bg-gray-750 rounded-lg p-4 border border-gray-100 dark:border-gray-700">
                        <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3 flex items-center">
                            <User className="w-4 h-4 mr-1.5 text-green-500" />
                            Abogado Interno
                        </h4>
                        {caseData?.internalLawyer ? (
                            <div className="flex items-center gap-3">
                                {caseData?.internalLawyer?.image ? (
                                    <Image
                                        className="w-10 h-10 rounded-full ring-2 ring-white dark:ring-gray-700"
                                        src={process.env.NEXT_PUBLIC_BACKEND_URL + caseData?.internalLawyer?.image || "/placeholder.svg"}
                                        alt={`${caseData?.internalLawyer?.name || "Lawyer"} profile`}
                                        width={40}
                                        height={40}
                                    />
                                ) : (
                                    <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center text-green-600 dark:text-green-300 text-sm font-medium">
                                        {caseData?.internalLawyer?.name ? caseData.internalLawyer.name.charAt(0).toUpperCase() : "L"}
                                    </div>
                                )}
                                <div>
                                    <p className="text-sm font-medium text-gray-800 dark:text-gray-200">
                                        {caseData?.internalLawyer?.name || "Sin asignar"}
                                    </p>
                                    <p className="text-xs text-gray-500 dark:text-gray-400">{caseData?.internalLawyer?.email || ""}</p>
                                </div>
                            </div>
                        ) : (
                            <div className="flex items-center gap-3 text-gray-500 dark:text-gray-400">
                                <div className="w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center">
                                    <User className="w-5 h-5 text-gray-400 dark:text-gray-500" />
                                </div>
                                <span className="text-sm">Sin asignar</span>
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Action buttons */}
            <div className="flex justify-between border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-750 px-6 py-4">
                <Button
                    variant="outline"
                    onClick={onEdit}
                    className="bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-650"
                >
                    <Edit className="mr-2 h-4 w-4" />
                    Editar
                </Button>
                <Button
                    variant="outline"
                    onClick={onDelete}
                    className="bg-white dark:bg-gray-700 border-red-200 dark:border-red-900 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20"
                >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Eliminar
                </Button>
            </div>
        </div>
    )
}

'use client'

import React, { useCallback, useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useParams } from 'next/navigation'

import FilesHeader from '@/components/files/FilesHeader'
import FilesDetails from '@/components/files/FilesDetails'
import FilesTabs from '@/components/files/FilesTab'

import { CASES_FILES_BY_CASE_ID_ENDPOINT } from '@/constant/api-endpoints'
import FilesSidebar from './FilesSidebar'
import FilesNewMovements from './FilesNewMovements'


export default function FilesContent() {
    const { caseId, id: fileId } = useParams()
    const { data: session } = useSession()
    const [file, setFile] = useState(null)
    const [isNewMovementOpen, setIsNewMovementOpen] = useState(false)

    const caseIdNum = Number(caseId)
    const fileIdNum = Number(fileId)

    const fetchFileData = useCallback(async () => {
        if (!caseIdNum || !fileIdNum || !session?.user?.accessToken) return

        try {
            const response = await fetch(
                CASES_FILES_BY_CASE_ID_ENDPOINT(caseIdNum, fileIdNum),
                {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${session.user.accessToken}`,
                    },
                }
            )

            const data = await response.json()
            console.log('Fetched file data:', data)
            setFile(data)
        } catch (error) {
            console.error("Error fetching file data:", error)
        }
    }, [caseIdNum, fileIdNum, session])

    useEffect(() => {
        fetchFileData()
    }, [fetchFileData])

    const handleFileUpdate = ({ updatedFile }: any) => {
        setFile(updatedFile)
        // You might want to refetch the data or perform other actions after update
        fetchFileData()
    }

    return (
        <div>
            {file && <FilesHeader file={file} />}

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                    {file && <FilesDetails file={file} />}
                    {file && <FilesTabs file={file} />}
                </div>

                <div className="space-y-6">
                    {file && <FilesSidebar file={file} onOpenNewMovement={() => setIsNewMovementOpen(true)} />}
                </div>
            </div>

            {file && (
                <FilesNewMovements
                    isOpen={isNewMovementOpen}
                    onClose={() => setIsNewMovementOpen(false)}
                    file={file}
                    onFileUpdate={handleFileUpdate}
                />
            )}
        </div>
    )
}

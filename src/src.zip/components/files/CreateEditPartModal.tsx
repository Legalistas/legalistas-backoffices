"use client"

import type React from "react"
import { useState, useEffect, useCallback } from "react"
import { Modal } from "@/components/ui/modal/Modal"
import Label from "@/components/ui/label/Label"
import Input from "@/components/ui/input/Input"
import { toast } from "sonner"
import { useSession } from "next-auth/react"
import { SETTINGS_COUNTRIES_ENDPOINT } from "@/constant/api-endpoints"
import { Loader2 } from "lucide-react"

export interface CaseParty {
    id?: number
    name: string
    email?: string
    phone?: string
    address?: string
    documentNumber?: string
    documentType?: string
    partyType: "DEMANDADO" | "DEMANDANTE" | "TERCERO" | "TESTIGO"
    role?: string
    notes?: string
    countryId?: number
    stateId?: number
    city?: string
}

interface Country {
    id: number
    name: string
    code?: string
    prefix?: string
    isActive?: boolean
    states?: State[]
}

interface State {
    id: number
    name: string
    countryId: number
}

interface CreateEditPartModalProps {
    open: boolean
    onClose: () => void
    part?: CaseParty | null
    onSave: (part: CaseParty) => void
}

export default function CreateEditPartModal({ open, onClose, part, onSave }: CreateEditPartModalProps) {
    const { data: session } = useSession()

    const [formData, setFormData] = useState<CaseParty>({
        name: "",
        email: "",
        phone: "",
        address: "",
        documentNumber: "",
        documentType: "DNI",
        partyType: "DEMANDADO",
        role: "",
        notes: "",
        countryId: undefined,
        stateId: undefined,
        city: "",
    })

    const [isSubmitting, setIsSubmitting] = useState(false)

    // Estados para países y estados
    const [countries, setCountries] = useState<Country[]>([])
    const [states, setStates] = useState<State[]>([])
    const [isLoadingCountries, setIsLoadingCountries] = useState(false)
    const [isLoadingStates, setIsLoadingStates] = useState(false)

    // Fetch countries
    const fetchCountries = useCallback(async () => {
        try {
            setIsLoadingCountries(true)
            const response = await fetch(`${SETTINGS_COUNTRIES_ENDPOINT}`, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${session?.user?.accessToken}`,
                },
            })

            if (!response.ok) {
                throw new Error(`Error fetching countries: ${response.status}`)
            }

            const data = await response.json()
            setCountries(data.data || [])

            // Si hay un país seleccionado, actualizar los estados
            if (formData.countryId) {
                const selectedCountry = data.data?.find((country: Country) => country.id === formData.countryId)
                if (selectedCountry && selectedCountry.states) {
                    setStates(selectedCountry.states)
                }
            }
        } catch (error) {
            console.error("Failed to fetch countries:", error)
            toast.error("Error al cargar los países")
        } finally {
            setIsLoadingCountries(false)
        }
    }, [session?.user?.accessToken, formData.countryId])

    // Load countries when modal opens
    useEffect(() => {
        if (open && session?.user?.accessToken) {
            fetchCountries()
        }
    }, [open, session?.user?.accessToken, fetchCountries])

    // Actualizar estados cuando cambia el país seleccionado
    useEffect(() => {
        if (formData.countryId) {
            const selectedCountry = countries.find((country) => country.id === Number(formData.countryId))
            if (selectedCountry && selectedCountry.states) {
                setStates(selectedCountry.states)
            } else {
                setStates([])
            }
        } else {
            setStates([])
            setFormData((prev) => ({ ...prev, stateId: undefined }))
        }
    }, [formData.countryId, countries])

    // Reset form when modal opens/closes or part changes
    useEffect(() => {
        if (open) {
            if (part) {
                // Editing existing part
                setFormData({
                    name: part.name || "",
                    email: part.email || "",
                    phone: part.phone || "",
                    address: part.address || "",
                    documentNumber: part.documentNumber || "",
                    documentType: part.documentType || "DNI",
                    partyType: part.partyType,
                    role: part.role || "",
                    notes: part.notes || "",
                    countryId: part.countryId || undefined,
                    stateId: part.stateId || undefined,
                    city: part.city || "",
                    id: part.id,
                })
            } else {
                // Creating new part
                setFormData({
                    name: "",
                    email: "",
                    phone: "",
                    address: "",
                    documentNumber: "",
                    documentType: "DNI",
                    partyType: "DEMANDADO",
                    role: "",
                    notes: "",
                    countryId: undefined,
                    stateId: undefined,
                    city: "",
                })
            }
        }
    }, [open, part])

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target

        if (name === "countryId") {
            const countryId = value ? Number(value) : undefined
            setFormData((prev) => ({
                ...prev,
                countryId,
                stateId: undefined, // Reset state when country changes
            }))
        } else if (name === "stateId") {
            const stateId = value ? Number(value) : undefined
            setFormData((prev) => ({ ...prev, stateId }))
        } else {
            setFormData((prev) => ({ ...prev, [name]: value }))
        }
    }

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()

        if (!formData.name.trim()) {
            toast.error("Por favor, ingrese el nombre de la parte")
            return
        }

        try {
            setIsSubmitting(true)
            onSave(formData)
            onClose()
            toast.success(part ? "Parte actualizada exitosamente" : "Parte agregada exitosamente")
        } catch (error) {
            console.error("Error saving part:", error)
            toast.error("Error al guardar la parte")
        } finally {
            setIsSubmitting(false)
        }
    }

    const handleClose = () => {
        if (!isSubmitting) {
            onClose()
        }
    }

    return (
        <Modal isOpen={open} onClose={handleClose} className="max-w-3xl mx-auto p-6">
            <div className="mb-6">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100">
                    {part ? "Editar Parte del Caso" : "Agregar Parte al Caso"}
                </h2>
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                    {part ? "Modifique la información de la parte" : "Complete la información de la parte involucrada en el caso"}
                </p>
            </div>

            <form onSubmit={handleSubmit}>
                <div className="space-y-4">
                    {/* Información básica */}
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="part-name">Nombre completo *</Label>
                            <Input
                                id="part-name"
                                name="name"
                                value={formData.name}
                                onChange={handleInputChange}
                                placeholder="Ingrese el nombre completo"

                                disabled={isSubmitting}
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="part-type">Tipo de Parte *</Label>
                            <select
                                id="part-type"
                                name="partyType"
                                value={formData.partyType}
                                onChange={handleInputChange}
                                disabled={isSubmitting}
                                className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300"
                            >
                                <option value="DEMANDADO">Demandado</option>
                                <option value="DEMANDANTE">Demandante</option>
                                <option value="TERCERO">Tercero</option>
                                <option value="TESTIGO">Testigo</option>
                            </select>
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="part-role">Rol/Función</Label>
                        <Input
                            id="part-role"
                            name="role"
                            value={formData.role}
                            onChange={handleInputChange}
                            placeholder="Ej: Representante legal, Apoderado, etc."
                            disabled={isSubmitting}
                        />
                    </div>

                    {/* Documentación */}
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="part-documentType">Tipo de Documento</Label>
                            <select
                                id="part-documentType"
                                name="documentType"
                                value={formData.documentType}
                                onChange={handleInputChange}
                                disabled={isSubmitting}
                                className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300"
                            >
                                <option value="DNI">DNI</option>
                                <option value="CUIT">CUIT</option>
                                <option value="CUIL">CUIL</option>
                                <option value="PASAPORTE">Pasaporte</option>
                                <option value="LC">Libreta Cívica</option>
                                <option value="LE">Libreta de Enrolamiento</option>
                            </select>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="part-documentNumber">Número de Documento</Label>
                            <Input
                                id="part-documentNumber"
                                name="documentNumber"
                                value={formData.documentNumber}
                                onChange={handleInputChange}
                                placeholder="Número"
                                disabled={isSubmitting}
                            />
                        </div>
                    </div>

                    {/* Información de contacto */}
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="part-email">Email</Label>
                            <Input
                                id="part-email"
                                name="email"
                                type="email"
                                value={formData.email}
                                onChange={handleInputChange}
                                placeholder="ejemplo@correo.com"
                                disabled={isSubmitting}
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="part-phone">Teléfono</Label>
                            <Input
                                id="part-phone"
                                name="phone"
                                value={formData.phone}
                                onChange={handleInputChange}
                                placeholder="11-1234-5678"
                                disabled={isSubmitting}
                            />
                        </div>
                    </div>

                    {/* Ubicación geográfica */}
                    <div className="border-t border-gray-200 dark:border-gray-600 pt-4">
                        <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-3">Ubicación</h4>

                        <div className="grid grid-cols-3 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="part-country">País</Label>
                                <div className="relative">
                                    <select
                                        id="part-country"
                                        name="countryId"
                                        value={formData.countryId || ""}
                                        onChange={handleInputChange}
                                        disabled={isSubmitting || isLoadingCountries}
                                        className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300"
                                    >
                                        <option value="">Seleccionar país</option>
                                        {countries.map((country) => (
                                            <option key={country.id} value={country.id}>
                                                {country.name}
                                            </option>
                                        ))}
                                    </select>
                                    {isLoadingCountries && (
                                        <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                                            <Loader2 className="h-4 w-4 animate-spin text-gray-400" />
                                        </div>
                                    )}
                                </div>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="part-state">Estado/Provincia</Label>
                                <div className="relative">
                                    <select
                                        id="part-state"
                                        name="stateId"
                                        value={formData.stateId || ""}
                                        onChange={handleInputChange}
                                        disabled={isSubmitting || isLoadingStates || !formData.countryId}
                                        className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300 disabled:opacity-50"
                                    >
                                        <option value="">Seleccionar estado</option>
                                        {states.map((state) => (
                                            <option key={state.id} value={state.id}>
                                                {state.name}
                                            </option>
                                        ))}
                                    </select>
                                    {isLoadingStates && (
                                        <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                                            <Loader2 className="h-4 w-4 animate-spin text-gray-400" />
                                        </div>
                                    )}
                                </div>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="part-city">Ciudad</Label>
                                <Input
                                    id="part-city"
                                    name="city"
                                    value={formData.city}
                                    onChange={handleInputChange}
                                    placeholder="Ciudad"
                                    disabled={isSubmitting}
                                />
                            </div>
                        </div>
                    </div>

                    {/* Dirección completa */}
                    <div className="space-y-2">
                        <Label htmlFor="part-address">Dirección completa</Label>
                        <Input
                            id="part-address"
                            name="address"
                            value={formData.address}
                            onChange={handleInputChange}
                            placeholder="Av. Ejemplo 123, Barrio, Código Postal"
                            disabled={isSubmitting}
                        />
                    </div>

                    {/* Notas */}
                    <div className="space-y-2">
                        <Label htmlFor="part-notes">Notas adicionales</Label>
                        <textarea
                            id="part-notes"
                            name="notes"
                            value={formData.notes}
                            onChange={handleInputChange}
                            rows={3}
                            disabled={isSubmitting}
                            className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300"
                            placeholder="Información adicional relevante sobre esta parte"
                        />
                    </div>
                </div>

                <div className="mt-6 flex justify-end gap-3">
                    <button
                        type="button"
                        onClick={handleClose}
                        disabled={isSubmitting}
                        className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600"
                    >
                        Cancelar
                    </button>
                    <button
                        type="submit"
                        disabled={isSubmitting || !formData.name.trim()}
                        className="rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isSubmitting ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin inline" />
                                Guardando...
                            </>
                        ) : part ? (
                            "Actualizar Parte"
                        ) : (
                            "Agregar Parte"
                        )}
                    </button>
                </div>
            </form>
        </Modal>
    )
}

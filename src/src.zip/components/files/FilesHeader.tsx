import { ArrowLeft, ChevronLeft, Download, Edit, Printer, Share2 } from "lucide-react";
import Button from "../ui/button/Button";
import Badge from "../ui/badge/Badge";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { getFileTypeLabel, getProceduralStageLabel, getStatusProcessLabel } from "@/lib/functions";


interface FilesHeaderProps {
    file?: {
        id: number;
        title: string;
        cuij: string;
        filetype: number;
        proceduralStageId: number;
        statusProcessId: number;
    }
}

export default function FilesHeader({ file }: FilesHeaderProps) {
    return (
        <header className="mb-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center">
                    <Button variant="outline" size="sm" className="mr-4 flex-shrink-0">
                        <ArrowLeft className="h-4 w-4" />
                    </Button>
                    <div>
                        <div className="flex items-center gap-3">
                            <h1 className="text-xl font-bold text-gray-900">{file?.title}</h1>
                            <Badge className="">
                                {getProceduralStageLabel(file?.proceduralStageId ?? 0, file?.filetype ?? 0)}
                            </Badge>
                            {/* {expediente.prioridad === "Alta" && (
                                    <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Prioridad Alta</Badge>
                                )} */}
                                
                        </div>
                        <p className="text-sm text-gray-500 mt-1">
                            <span className="font-medium">{file?.cuij}</span> • {file?.filetype !== undefined ? getFileTypeLabel(file.filetype) : "Tipo desconocido"} • {getStatusProcessLabel(file?.statusProcessId ?? 0)}
                        </p>
                    </div>
                </div>

                <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                        <Printer className="h-4 w-4" />
                        Imprimir
                    </Button>
                    <Button variant="outline" size="sm">
                        <Download className="h-4 w-4" />
                        Descargar
                    </Button>
                    <Button variant="outline" size="sm">
                        <Share2 className="h-4 w-4" />
                        Compartir
                    </Button>
                    <Button size="sm">
                        <Edit className="h-4 w-4" />
                        Editar
                    </Button>
                </div>
            </div>
        </header>
    )
}
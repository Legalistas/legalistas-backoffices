import { Calendar, CalendarClock, Clock3, FileText, Scale } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card/Card";
import { Separator } from "../ui/Separator";
import { Progress } from "../ui/Progress";
import { formatDateCustom } from "@/lib/functions";
import { CasesFiles } from "@/types/cases";

export interface FilesHeaderProps {
    file?: CasesFiles;
}

export default function FilesDetails({ file }: FilesHeaderProps) {
    return (
        <Card className="p-4">
            <CardHeader className="pb-3">
                <CardTitle>Información General</CardTitle>
                <CardDescription>Detalles principales del expediente</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="flex items-start">
                            <FileText className="h-5 w-5 text-gray-400 mr-2 mt-0.5" />
                            <div>
                                <p className="text-xs text-gray-500">Descripción</p>
                                <p className="text-sm">{file?.observation}</p>
                            </div>
                        </div>
                        <div className="flex items-start">
                            <Scale className="h-5 w-5 text-gray-400 mr-2 mt-0.5" />
                            <div>
                                <p className="text-xs text-gray-500">Radicación | Juzgado</p>
                                <p className="text-sm font-medium">
                                    { file?.court?.jurisdiction?.name }
                                </p>
                                <p className="text-xs text-gray-500 mt-1">{ file?.court?.courtName }</p>
                            </div>
                        </div>
                    </div>
                    <Separator />
                    <div>
                        <div className="flex justify-between items-center mb-2">
                            <div className="flex items-center">
                                <Clock3 className="h-5 w-5 text-gray-400 mr-2" />
                                <span className="text-sm font-medium">Progreso del caso</span>
                            </div>
                            <span className="text-sm font-medium">{ }%</span>
                        </div>
                        <Progress value={0} className="h-2" />
                        <p className="text-xs text-gray-500 mt-2">Etapa actual: </p>
                    </div>
                    <Separator />
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="flex items-center">
                            <Calendar className="h-5 w-5 text-gray-400 mr-2" />
                            <div>
                                <p className="text-xs text-gray-500">Fecha de inicio</p>
                                <p className="text-sm font-medium">{formatDateCustom(file?.createdAt)}</p>
                            </div>
                        </div>

                        <div className="flex items-center">
                            <Clock3 className="h-5 w-5 text-gray-400 mr-2" />
                            <div>
                                <p className="text-xs text-gray-500">Última actualización</p>
                                <p className="text-sm font-medium">{formatDateCustom(file?.updatedAt)}</p>
                            </div>
                        </div>

                        <div className="flex items-center">
                            <CalendarClock className="h-5 w-5 text-gray-400 mr-2" />
                            <div>
                                <p className="text-xs text-gray-500">Próxima audiencia</p>
                                <p className="text-sm font-medium">
                                    {file?.endDate} - {file?.startDate}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </CardContent>
        </Card>
    )
}
"use client"
import { useState, useEffect } from "react"
import { MessageCircle, X } from "lucide-react"
import { useRouter } from "next/navigation"
import { useChat } from "@/context/ChatContext"
import { motion, AnimatePresence } from "framer-motion"
import Image from "next/image"

interface FloatingChatBubbleProps {
    position?: "bottom-right" | "bottom-left" | "top-right" | "top-left"
    offset?: number
}

export default function FloatingChatBubble({ position = "bottom-right", offset = 20 }: FloatingChatBubbleProps) {
    const [isOpen, setIsOpen] = useState(false)
    const [unreadCount, setUnreadCount] = useState(0)
    const [hasNewMessage, setHasNewMessage] = useState(false)
    const router = useRouter()
    const { recentChats } = useChat()
    
    // Usar valores fijos para la posición en lugar de clases dinámicas
    const getPositionStyles = () => {
        switch (position) {
            case "bottom-right":
                return { bottom: `${offset}px`, right: `${offset}px` }
            case "bottom-left":
                return { bottom: `${offset}px`, left: `${offset}px` }
            case "top-right":
                return { top: `${offset}px`, right: `${offset}px` }
            case "top-left":
                return { top: `${offset}px`, left: `${offset}px` }
            default:
                return { bottom: `${offset}px`, right: `${offset}px` }
        }
    }

    // Actualizar el contador de mensajes no leídos
    useEffect(() => {
        const totalUnread = recentChats.reduce((total, chat) => total + chat.unreadCount, 0)

        if (totalUnread > unreadCount) {
            setHasNewMessage(true)
            // Resetear la animación después de 2 segundos
            const timer = setTimeout(() => {
                setHasNewMessage(false)
            }, 2000)
            return () => clearTimeout(timer)
        }

        setUnreadCount(totalUnread)
    }, [recentChats, unreadCount])

    // Navegar a la página de chat
    const handleOpenChat = () => {
        router.push("/admin/chat")
    }

    // Obtener los estilos de posición
    const positionStyles = getPositionStyles()

    return (
        <div className="fixed z-[9999]" style={positionStyles} data-testid="floating-chat-bubble">
            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ opacity: 0, scale: 0.5, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.5, y: 20 }}
                        className="absolute bottom-16 right-0 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4 w-64 border border-gray-200 dark:border-gray-700"
                    >
                        <div className="flex justify-between items-center mb-3">
                            <h3 className="font-medium text-gray-800 dark:text-white">Mensajes</h3>
                            <button
                                onClick={() => setIsOpen(false)}
                                className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
                            >
                                <X size={18} />
                            </button>
                        </div>

                        <div className="space-y-2 max-h-60 overflow-y-auto">
                            {recentChats.length > 0 ? (
                                recentChats.slice(0, 3).map((chat) => (
                                    <div
                                        key={chat.user.id}
                                        className="flex items-center gap-2 p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md cursor-pointer"
                                        onClick={handleOpenChat}
                                    >
                                        <div className="relative w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-600 flex items-center justify-center overflow-hidden">
                                            {chat.user.image ? (
                                                <>
                                                    <Image
                                                        src={`${process.env.NEXT_PUBLIC_BACKEND_URL}${chat.user.image}` || "/images/placeholder.svg"}
                                                        alt={chat.user?.name || "User Avatar"}
                                                        width={40}
                                                        height={40}
                                                        quality={100}
                                                        priority
                                                        className="h-full w-full object-cover object-center rounded-full"
                                                    /></>
                                            ) : (
                                                <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-blue-600 dark:text-blue-300 text-sm font-medium">
                                                    {chat.user?.name ? chat.user.name.charAt(0).toUpperCase() : "L"}
                                                </div>
                                            )}
                                            {chat.unreadCount > 0 && (
                                                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                                                    {chat.unreadCount}
                                                </span>
                                            )}
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <p className="text-sm font-medium text-gray-800 dark:text-white truncate">{chat.user.name}</p>
                                            <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
                                                {chat.lastMessage?.content || "No hay mensajes"}
                                            </p>
                                        </div>
                                    </div>
                                ))
                            ) : (
                                <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-2">No hay mensajes recientes</p>
                            )}
                        </div>

                        <button
                            onClick={handleOpenChat}
                            className="w-full mt-3 py-2 bg-brand-500 hover:bg-brand-600 text-white rounded-md text-sm font-medium transition-colors"
                        >
                            Ver todos los mensajes
                        </button>
                    </motion.div>
                )}
            </AnimatePresence>

            <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setIsOpen(!isOpen)}
                className="relative flex items-center justify-center w-14 h-14 rounded-full bg-blue-500 hover:bg-blue-600 text-white shadow-lg transition-colors"
                animate={hasNewMessage ? { y: [0, -10, 0] } : {}}
            >
                <MessageCircle size={24} />
                {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full min-w-5 h-5 flex items-center justify-center px-1">
                        {unreadCount > 99 ? "99+" : unreadCount}
                    </span>
                )}
            </motion.button>
        </div>
    )
}

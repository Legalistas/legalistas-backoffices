"use client"

import Button from "@/components/ui/button/Button"
import { ChevronFirst, ChevronLast, ChevronLeft, ChevronRight } from "lucide-react"

interface PaginationProps {
    currentPage: number
    totalPages: number
    totalItems: number
    itemsPerPage: number
    onPageChange: (page: number) => void
}

export const Pagination = ({
    currentPage,
    totalPages,
    totalItems,
    itemsPerPage,
    onPageChange,
}: PaginationProps) => {
    if (totalPages <= 1) return null

    return (
        <div className="flex items-center justify-between mt-2">
            <div className="flex flex-1 justify-between sm:hidden">
                <Button variant="outline" onClick={() => onPageChange(currentPage - 1)} disabled={currentPage === 1}>
                    <ChevronFirst className="mr-2 h-4 w-4" />
                </Button>
                <Button variant="outline" onClick={() => onPageChange(currentPage + 1)} disabled={currentPage === totalPages}>
                    <ChevronLast className="mr-2 h-4 w-4" />
                </Button>
            </div>
            <div className="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between gap-2">
                <div>
                    <p className="text-sm text-gray-700">
                        Mostrando <span className="font-medium">{(currentPage - 1) * itemsPerPage + 1}</span> a{" "}
                        <span className="font-medium">{Math.min(currentPage * itemsPerPage, totalItems)}</span> de{" "}
                        <span className="font-medium">{totalItems}</span> Resultados
                    </p>
                </div>
                <div>
                    <nav className="inline-flex space-x-1" aria-label="Pagination">
                        <Button
                            variant="outline"
                            className="rounded-l-md"
                            onClick={() => onPageChange(currentPage - 1)}
                            disabled={currentPage === 1}
                        >
                            <ChevronLeft className="h-4 w-4" />
                        </Button>
                        {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                            <Button
                                key={page}
                                variant={page === currentPage ? "primary" : "outline"}
                                onClick={() => onPageChange(page)}
                            >
                                {page}
                            </Button>
                        ))}
                        <Button
                            variant="outline"
                            className="rounded-r-md"
                            onClick={() => onPageChange(currentPage + 1)}
                            disabled={currentPage === totalPages}
                        >
                            <ChevronRight className="h-4 w-4" />
                        </Button>
                    </nav>
                </div>
            </div>
        </div>
    )
}


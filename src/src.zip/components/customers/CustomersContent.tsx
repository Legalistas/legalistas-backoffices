"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSession } from "next-auth/react";
import { User } from "@/types/users";
import { toast } from "sonner";
import { USERS_ENDPOINT } from "@/constant/api-endpoints";
import { fetchData } from "next-auth/client/_utils";
import Button from "../ui/button/Button";
import { Filter, Loader2, Plus, Search } from "lucide-react";
import Input from "../ui/input/Input";
import CustomersTable from "./CustomersTable";
import { Pagination } from "../ui/pagination/Pagination";
import CustomerRegistrationModal from "./CustomerRegistrationModal";

interface ApiResponse {
    data: User[]
    meta: {
        total: number
        page: number
        limit: number
        totalPages: number
    }
}


export default function CustomersContent() {
    const { data: session } = useSession()
    const [allCustomers, setAllCustomers] = useState<any[]>([])
    const [loading, setLoading] = useState(false)
    const [currentPage, setCurrentPage] = useState(1)
    const [searchTerm, setSearchTerm] = useState("")
    const [selectedRoles, setSelectedRoles] = useState<string[]>([])
    const [showFilters, setShowFilters] = useState(false)
    const [originalPagination, setOriginalPagination] = useState({
        page: 1,
        limit: 10,
        total: 0,
        totalPages: 0,
    })
    const [hasSearched, setHasSearched] = useState(false)
    const [customerModalOpen, setCustomerModalOpen] = useState(false)
    const [editingCustomer, setEditingCustomer] = useState<User | null>(null)
    const [modalMode, setModalMode] = useState<"create" | "edit">("create")

    // Use refs to track if this is the initial render
    const isInitialRender = useRef(true)
    const searchTimeoutRef = useRef<NodeJS.Timeout | null>(null)
    const searchInputRef = useRef<HTMLInputElement>(null)

    // Filtrado local de clientes
    const filteredCustomers = useMemo(() => {
        let filtered = [...allCustomers]

        // Filtrar por término de búsqueda
        if (searchTerm.trim()) {
            const searchLower = searchTerm.toLowerCase().trim()
            filtered = filtered.filter((customer) => {
                return (
                    customer.name?.toLowerCase().includes(searchLower) ||
                    customer.email?.toLowerCase().includes(searchLower) ||
                    customer.roleUser?.[0]?.role?.displayName?.toLowerCase().includes(searchLower)
                )
            })
        }

        // Filtrar por roles seleccionados
        if (selectedRoles.length > 0) {
            filtered = filtered.filter((customer) => {
                // Verificar si el cliente tiene alguno de los roles seleccionados
                return customer.roleUser?.some((roleUser: any) => {
                    return selectedRoles.includes(roleUser.roleId?.toString())
                })
            })
        }

        return filtered
    }, [allCustomers, searchTerm, selectedRoles])

    // Paginación local
    const paginatedCustomers = useMemo(() => {
        const itemsPerPage = 10
        const startIndex = (currentPage - 1) * itemsPerPage
        const endIndex = startIndex + itemsPerPage
        return filteredCustomers.slice(startIndex, endIndex)
    }, [filteredCustomers, currentPage])

    // Calcular paginación basada en filtros locales
    const localPagination = useMemo(() => {
        const itemsPerPage = 10
        const totalPages = Math.ceil(filteredCustomers.length / itemsPerPage)
        return {
            page: currentPage,
            limit: itemsPerPage,
            total: filteredCustomers.length,
            totalPages: totalPages || 1,
        }
    }, [filteredCustomers.length, currentPage])

    const fetchCustomers = useCallback(async () => {
        try {
            setLoading(true)
            // Obtener todos los clientes sin filtros
            const url = new URL(`${USERS_ENDPOINT}`, window.location.origin)
            url.searchParams.append("page", "1")
            url.searchParams.append("limit", "1000") // Obtener todos los clientes

            const response = await fetch(url.toString(), {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${session?.user?.accessToken}`,
                },
            })

            if (!response.ok) {
                const errorData = await response.json()
                throw new Error(errorData.message || "Failed to fetch members")
            }

            const result: ApiResponse = await response.json()

            // Si quieres filtrar solo por "cliente"
            const clientesOnly = result.data.filter(user => {
                return user.roleUser.some(roleUser =>
                    roleUser.role.name === "cliente"
                )
            })

            setAllCustomers(clientesOnly)
            setOriginalPagination({
                page: result.meta.page,
                limit: result.meta.limit,
                total: clientesOnly.length,
                totalPages: Math.ceil(clientesOnly.length / result.meta.limit),
            })
        } catch (error) {
            toast.error("Error al cargar los clientes")
        } finally {
            setLoading(false)
        }
    }, [session?.user?.accessToken])

    // Initial fetch on component mount
    useEffect(() => {
        if (isInitialRender.current && session?.user?.accessToken) {
            fetchCustomers()
            isInitialRender.current = false
        }
    }, [currentPage, fetchCustomers, searchTerm, selectedRoles, session?.user?.accessToken])

    // Reset page when filters change
    useEffect(() => {
        setCurrentPage(1)
    }, [searchTerm, selectedRoles])

    const handleDelete = useCallback(
        async (id: number) => {
            try {
                const response = await fetch(`${USERS_ENDPOINT}/${id}`, {
                    method: "DELETE",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${session?.user?.accessToken}`,
                    },
                })

                if (!response.ok) {
                    throw new Error("Failed to delete user")
                }

                toast.success("Miembro eliminado correctamente")
                // Recargar todos los miembros después de eliminar
                fetchCustomers()
            } catch (error) {
                console.error("Error al eliminar el miembro:", error)
                toast.error("Error al eliminar el miembro")
            }
        },
        [session?.user?.accessToken, fetchCustomers],
    )

    const handleClearSearch = useCallback(() => {
        setSearchTerm("")
        setSelectedRoles([])
        setHasSearched(false)
        setShowFilters(false)
        setCurrentPage(1)
    }, [])

    const handleSearchChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        setSearchTerm(e.target.value)
        setHasSearched(e.target.value.trim().length > 0)
    }, [])

    const handleSearch = useCallback((e: React.FormEvent) => {
        e.preventDefault()
        const inputValue = searchInputRef.current?.value || ""
        setSearchTerm(inputValue)
        setHasSearched(inputValue.trim().length > 0)
    }, [])

    const handlePageChange = useCallback((page: number) => {
        setCurrentPage(page)
    }, [])

    const handleRoleChange = useCallback((roles: string[]) => {
        console.log("Roles selected:", roles)
        setSelectedRoles(roles)
        setCurrentPage(1) // Reset to first page when filters change
    }, [])

    // Check if any filters are active
    const hasActiveFilters = Boolean(searchTerm.trim() || selectedRoles.length > 0)

    // No se requiere handleCustomerSelect porque no hay formulario; 
    // el cliente se selecciona directamente del fetch de contactos para convertirlo en cliente.

    const handleCustomerCreated = (newCustomer: any) => {
        toast.success("Cliente creado correctamente")
        setCustomerModalOpen(false)
        setEditingCustomer(null)
        setModalMode("create")
        fetchCustomers() // Recargar datos después de crear
    }

    const handleEdit = useCallback((customer: User) => {
        setEditingCustomer(customer)
        setModalMode("edit")
        setCustomerModalOpen(true)
    }, [])

    const handleCustomerUpdated = (updatedCustomer: any) => {
        toast.success("Cliente actualizado correctamente")
        setEditingCustomer(null)
        setModalMode("create")
        fetchCustomers() // Recargar datos después de actualizar
    }

    const refreshCustomers = async () => {
        await fetchCustomers()
    }

    // Loading state
    if (loading && allCustomers.length === 0 && !hasSearched) {
        return (
            <div>
                <div className="flex h-full flex-1 flex-col justify-center items-center gap-4 rounded-xl p-4">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
            </div>
        )
    }

    // Render the main content
    // if (allCustomers.length === 0 && !loading) {
    //     return (
    //         <div className="flex h-full flex-1 flex-col justify-center items-center gap-4 rounded-xl p-4">
    //             <p className="text-gray-500">No se encontraron clientes.</p>
    //         </div>
    //     )
    // }



    return (
        <div>
            <div className="flex flex-col gap-6 mb-2">
                {/* Header */}
                <div className="flex items-center justify-between">
                    <h1 className="text-3xl font-bold tracking-tight text-black dark:text-gray-100">Clientes</h1>
                    <Button
                        variant="custom"
                        size="sm"
                        className="flex items-center gap-2 bg-[#09A4B5] text-white hover:bg-[#09A4B5]/80 hover:text-gray-dark p-2"
                        onClick={() => setCustomerModalOpen(true)}
                    >
                        <Plus className="h-4 w-4" />
                        Nuevo cliente
                    </Button>
                </div>

                {/* Filters */}
                <div className="flex flex-col gap-4">
                    <div className="flex flex-wrap items-center gap-3">
                        <div className="relative flex-1 min-w-[200px]">
                            <form onSubmit={handleSearch} className="w-full">
                                <div className="relative">
                                    <div className="absolute -translate-y-1/2 left-4 top-1/2 pointer-events-none">
                                        <Search className="w-5 h-5 stroke-gray-500 dark:stroke-gray-400" />
                                    </div>
                                    <Input
                                        type="search"
                                        placeholder="Buscar cliente..."
                                        className="dark:bg-dark-900 h-11 w-full rounded-lg border border-gray-200 bg-transparent py-2.5 pl-12 pr-14 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-800 dark:bg-gray-900 dark:bg-white/[0.03] dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800 xl:w-[430px]"
                                        defaultValue={searchTerm}
                                        onChange={handleSearchChange}
                                        ref={searchInputRef}
                                    />
                                    {searchTerm && (
                                        <button
                                            type="button"
                                            onClick={() => {
                                                setSearchTerm("")
                                                setHasSearched(false)
                                            }}
                                            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                                        >
                                            <span className="sr-only">Clear search</span>
                                            <svg
                                                xmlns="http://www.w3.org/2000/svg"
                                                width="16"
                                                height="16"
                                                viewBox="0 0 24 24"
                                                fill="none"
                                                stroke="currentColor"
                                                strokeWidth="2"
                                                strokeLinecap="round"
                                                strokeLinejoin="round"
                                            >
                                                <line x1="18" y1="6" x2="6" y2="18"></line>
                                                <line x1="6" y1="6" x2="18" y2="18"></line>
                                            </svg>
                                        </button>
                                    )}
                                </div>
                            </form>
                        </div>

                        <div className="flex items-center gap-2">

                        </div>
                    </div>

                </div>
                {/* Table */}
                <div className="overflow-hidden rounded-xl border border-gray-200 bg-white">
                    <div className="w-full overflow-x-auto">
                        <CustomersTable
                            customers={paginatedCustomers}
                            hasActiveFilters={hasActiveFilters}
                            handleClearSearch={handleClearSearch}
                            handleEdit={handleEdit}
                            handleDelete={handleDelete}
                            isLoading={loading}
                        />
                    </div>
                </div>

                {/* Pagination */}
                <Pagination
                    currentPage={localPagination.page}
                    totalPages={localPagination.totalPages}
                    totalItems={localPagination.total}
                    itemsPerPage={localPagination.limit}
                    onPageChange={handlePageChange}
                />
            </div>

            {/* Customer Modal */}
            <CustomerRegistrationModal
                isOpen={customerModalOpen}
                onClose={() => {
                    setCustomerModalOpen(false)
                    setEditingCustomer(null)
                    setModalMode("create")
                }}
                onCustomerCreated={handleCustomerCreated}
                onCustomerUpdated={handleCustomerUpdated}
                onRefreshCustomers={refreshCustomers}
                editingCustomer={editingCustomer}
                mode={modalMode}
            />
        </div>
    );
}

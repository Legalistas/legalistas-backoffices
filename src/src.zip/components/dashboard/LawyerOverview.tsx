"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card/Card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs/Tabs"
import { ArrowDown, ArrowUp, CheckCircle, FileCheck, Scale, XCircle } from "lucide-react"
import { STATISTICS_LAW_DASHBOARD_ENDPOINT } from "@/constant/api-endpoints"

export function LawyerOverview() {
    const { data: session } = useSession()
    const [timeframe, setTimeframe] = useState("day")
    const [data, setData] = useState({
        casesCreated: 0,
        casesWon: 0,
        casesLost: 0,
        tasaConversion: 0,
        tendenciaCreadas: 0,
        tendenciaGanadas: 0,
        tendenciaPerdidas: 0,
        tendenciaConversion: 0,
    })

    useEffect(() => {
        async function fetchStatistics() {
            if (!session?.user?.id || !session?.user?.accessToken) return

            try {
                const res = await fetch(`${STATISTICS_LAW_DASHBOARD_ENDPOINT}/${session?.user?.id}?timeframe=${timeframe}`, {
                    headers: {
                        Authorization: `Bearer ${session?.user?.accessToken}`,
                    },
                })

                if (!res.ok) {
                    console.error("Error fetching legal statistics")
                    return
                }

                const stats = await res.json()
                setData(stats.statsCard)
            } catch (error) {
                console.error("Error fetching legal statistics:", error)
            }
        }

        fetchStatistics()
    }, [session, timeframe])

    const currentData = data

    return (
        <div>
            <Tabs defaultValue="day" className="w-full bg-white" onValueChange={setTimeframe}>
                <div className="w-full">
                    <TabsList>
                        <TabsTrigger value="day">Hoy</TabsTrigger>
                        <TabsTrigger value="month">Este Mes</TabsTrigger>
                        <TabsTrigger value="year">Este Año</TabsTrigger>
                    </TabsList>
                </div>

                <TabsContent value={timeframe}>
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                        <StatCard
                            title="Causas a mi nombre"
                            value={currentData.casesCreated}
                            trend={currentData.tendenciaCreadas}
                            icon={<Scale className="h-4 w-4 text-muted-foreground" />}
                        />
                        <StatCard
                            title="Causas Ganadas"
                            value={currentData.casesWon}
                            trend={currentData.tendenciaGanadas}
                            icon={<CheckCircle className="h-4 w-4 text-muted-foreground" />}
                        />
                        <StatCard
                            title="Causas Perdidas"
                            value={currentData.casesLost}
                            trend={currentData.tendenciaPerdidas}
                            icon={<XCircle className="h-4 w-4 text-muted-foreground" />}
                        />
                        <StatCard
                            title="Tasa de Conversión"
                            value={`${currentData.tasaConversion}%`}
                            trend={currentData.tendenciaConversion}
                            icon={<FileCheck className="h-4 w-4 text-muted-foreground" />}
                        />
                    </div>
                </TabsContent>
            </Tabs>
        </div>
    )
}

function StatCard({
    title,
    value,
    trend,
    icon,
}: { title: string; value: number | string; trend: number; icon: React.ReactNode }) {
    return (
        <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{title}</CardTitle>
                {icon}
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{value}</div>
                <div className="flex items-center text-xs text-muted-foreground">
                    {trend >= 0 ? (
                        <>
                            <ArrowUp className="mr-1 h-3 w-3 text-emerald-500" />
                            <span className="text-emerald-500">{trend}%</span>
                        </>
                    ) : (
                        <>
                            <ArrowDown className="mr-1 h-3 w-3 text-rose-500" />
                            <span className="text-rose-500">{Math.abs(trend)}%</span>
                        </>
                    )}
                    <span className="ml-1">vs. período anterior</span>
                </div>
            </CardContent>
        </Card>
    )
}

import { Lead } from "@/types/crm";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card/Card";
import { Table, TableBody, TableCell, TableHeader, TableRow } from "../ui/table";
import { CRM_COLUMNS, SOURCE_CHANNEL } from "@/constant/crm";
import Badge from "../ui/badge/Badge";
import { ChevronLeft, ChevronRight, Eye, Pencil, Trash } from "lucide-react";
import { useState } from "react";
import Button from "../ui/button/Button";
import Link from "next/link";

interface KanbanListProps {
    leads: Lead[];
    onEditLead: (lead: Lead) => void;
    onDeleteLead: (leadId: string) => void;
}

export default function KanbanList({ leads, onEditLead, onDeleteLead }: KanbanListProps) {
    const [currentPage, setCurrentPage] = useState(1)
    const [itemsPerPage, setItemsPerPage] = useState(10)
    console.log("Leads", leads)

    const getSourceChannelLabel = (sourceChannelId: number | undefined) => {
        if (!sourceChannelId) return "Desconocido"

        const channel = SOURCE_CHANNEL.find((ch) => ch.id === sourceChannelId)
        return channel ? channel.name : `Canal ${sourceChannelId}`
    }

    const getColumnLabel = (columnId: number | undefined) => {
        if (!columnId) return "Desconocido"

        const column = CRM_COLUMNS.find((col) => String(col.id) === String(columnId))
        return column ? column.title : `Columna ${columnId}`
    }

    // Pagination logic
    const totalPages = Math.ceil(leads.length / itemsPerPage)
    const indexOfLastItem = currentPage * itemsPerPage
    const indexOfFirstItem = indexOfLastItem - itemsPerPage
    const currentLeads = leads.slice(indexOfFirstItem, indexOfLastItem)

    const handlePageChange = (pageNumber: number) => {
        setCurrentPage(pageNumber)
    }

    const handlePrevious = () => {
        if (currentPage > 1) {
            setCurrentPage(currentPage - 1)
        }
    }

    const handleNext = () => {
        if (currentPage < totalPages) {
            setCurrentPage(currentPage + 1)
        }
    }

    // Generate page numbers
    const pageNumbers = []
    const maxPageButtons = 5
    let startPage = Math.max(1, currentPage - Math.floor(maxPageButtons / 2))
    const endPage = Math.min(totalPages, startPage + maxPageButtons - 1)

    if (endPage - startPage + 1 < maxPageButtons) {
        startPage = Math.max(1, endPage - maxPageButtons + 1)
    }

    for (let i = startPage; i <= endPage; i++) {
        pageNumbers.push(i)
    }

    return (
        <div>
            <div></div>
            <div className="overflow-hidden rounded-xl border border-gray-200 bg-white">
                <div className="w-full overflow-x-auto">
                    <Table className="w-full min-w-[800px]">
                        <TableHeader className="bg-gray-50">
                            <TableRow>
                                <TableCell isHeader className="w-[1%] px-4 py-3 text-sm font-semibold text-gray-700 text-left">ID</TableCell>
                                <TableCell isHeader className="w-[10%] px-4 py-3 text-sm font-semibold text-gray-700 text-left">Cliente</TableCell>
                                <TableCell isHeader className="w-[10%] px-4 py-3 text-sm font-semibold text-gray-700 text-left">Provincia</TableCell>
                                <TableCell isHeader className="w-[10%] px-4 py-3 text-sm font-semibold text-gray-700 text-left">Ciudad</TableCell>
                                <TableCell isHeader className="w-auto px-4 py-3 text-sm font-semibold text-gray-700 text-left">Servicios</TableCell>
                                <TableCell isHeader className="w-[10%] px-4 py-3 text-sm font-semibold text-gray-700 text-left">Canal ingreso</TableCell>
                                <TableCell isHeader className="w-[14%] px-4 py-3 text-sm font-semibold text-gray-700 text-left">Etapa</TableCell>
                                <TableCell isHeader className="w-[10%] px-4 py-3 text-sm font-semibold text-gray-700 text-left">Vendedora</TableCell>
                                <TableCell isHeader className="w-[12%] px-4 py-3 text-sm font-semibold text-gray-700 text-left">Abog. Interno</TableCell>
                                <TableCell isHeader className="w-[12%] px-4 py-3 text-sm font-semibold text-gray-700 text-left">Abog. Responsable</TableCell>
                                <TableCell isHeader className="w-[4%] px-4 py-3 text-sm font-semibold text-gray-700 text-left">Acciones</TableCell>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {leads.map((lead) => (
                                <TableRow key={lead.id}>
                                    <TableCell className="px-4 py-3 text-sm text-gray-700">{lead.id}</TableCell>
                                    <TableCell className="px-4 py-3 text-sm text-gray-700">{lead.user?.name}</TableCell>
                                    <TableCell className="px-4 py-3 text-sm text-gray-700">{lead.user?.userAddresses[0]?.state?.name}</TableCell>
                                    <TableCell className="px-4 py-3 text-sm text-gray-700">{lead.user?.userAddresses[0]?.city}</TableCell>
                                    <TableCell className="px-4 py-3 text-sm text-gray-700">
                                        {lead.services && (
                                            <Badge
                                                variant="light"
                                                className="text-xs flex items-center gap-1 bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-400"
                                            >
                                                {lead.services.label}
                                            </Badge>
                                        )}
                                    </TableCell>
                                    <TableCell className="px-4 py-3 text-sm text-gray-700">
                                        <Badge
                                            variant="light"
                                            className="text-xs flex items-center gap-1 bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-400"
                                        >
                                            {getSourceChannelLabel(lead.sourceChannelId)}
                                        </Badge>
                                    </TableCell>
                                    <TableCell className="px-4 py-3 text-sm text-gray-700">{getColumnLabel(Number(lead.columnId))}</TableCell>
                                    <TableCell className="px-4 py-3 text-sm text-gray-700">{lead.seller?.name}</TableCell>
                                    <TableCell className="px-4 py-3 text-sm text-gray-700">{lead.internalLawyer?.name}</TableCell>
                                    <TableCell className="px-4 py-3 text-sm text-gray-700">{lead.responsibleLawyer?.name}</TableCell>
                                    <TableCell className="px-4 py-3 text-sm text-gray-700">
                                        <div className="flex items-center gap-2">
                                            <Link href={`/admin/crm/leads/${lead.id}`} className="text-gray-500 hover:text-gray-700 p-2 hover:bg-blue-100 rounded">
                                               <Eye className="h-4 w-4" />
                                            </Link>
                                            <button onClick={() => onEditLead(lead)} className="text-blue-500 hover:text-blue-700 p-2 hover:bg-blue-100 rounded">
                                                <Pencil className="h-4 w-4" />
                                            </button>
                                            <button onClick={() => onDeleteLead(lead.id)} className="text-red-500 hover:text-red-700 p-2 hover:bg-blue-100 rounded">
                                                <Trash className="h-4 w-4" />
                                            </button>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
            </div>
            {/* Pagination */}
            <div className="flex items-center justify-between px-4 py-3 border-t border-gray-200 bg-gray-50">
                <div className="flex items-center text-sm text-gray-500">
                    Mostrando <span className="font-medium mx-1">{indexOfFirstItem + 1}</span> a{" "}
                    <span className="font-medium mx-1">{Math.min(indexOfLastItem, leads.length)}</span> de{" "}
                    <span className="font-medium mx-1">{leads.length}</span> resultados
                </div>
                <div className="flex items-center space-x-2">
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={handlePrevious}
                        disabled={currentPage === 1}
                        className="flex items-center gap-1 px-2 py-1 text-sm"
                    >
                        <ChevronLeft className="h-4 w-4" />
                        Anterior
                    </Button>

                    <div className="flex items-center space-x-1">
                        {pageNumbers.map((number) => (
                            <Button
                                key={number}
                                variant={currentPage === number ? "primary" : "outline"}
                                size="sm"
                                onClick={() => handlePageChange(number)}
                                className={`px-3 py-1 text-sm ${currentPage === number ? "bg-indigo-600 text-white" : ""}`}
                            >
                                {number}
                            </Button>
                        ))}
                    </div>

                    <Button
                        variant="outline"
                        size="sm"
                        onClick={handleNext}
                        disabled={currentPage === totalPages}
                        className="flex items-center gap-1 px-2 py-1 text-sm"
                    >
                        Siguiente
                        <ChevronRight className="h-4 w-4" />
                    </Button>
                </div>
            </div>
        </div>
    )
}
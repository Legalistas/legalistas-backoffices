"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { toast } from "sonner"
import { Loader2, Plus } from "lucide-react"
import { DataNotFound } from "../common/DataNotFound"
import { CasesHeader } from "./CasesHeader"
import { CasesFilters } from "./CasesFilters"
import { CasesCardView } from "./CasesCardView"
import { CasesListView } from "./CasesListView"
import type { Cases } from "@/types/cases"
import { CASES_ENDPOINT, LAWYERS_ENDPOINT } from "@/constant/api-endpoints"
import { useSession } from "next-auth/react"
import { Pagination } from "../ui/pagination/Pagination"
import { Role } from "@/constant/user"
import { useRouter, useSearchParams } from "next/navigation"

interface LawyerOption {
  id: string
  value: string
  label: string
}

interface ApiResponse {
  data: Cases[]
  meta: {
    total: number
    page: number
    limit: number
    totalPages: number
  }
}

export default function CasesContent() {
  const { data: session } = useSession()
  const [cases, setCases] = useState<Cases[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const [searchTerm, setSearchTerm] = useState("")
  const [viewMode, setViewMode] = useState<"card" | "list">("list")
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 10,
    total: 0,
    totalPages: 0,
  })
  const [hasSearched, setHasSearched] = useState(false)
  const [selectedService, setSelectedService] = useState<number | undefined>(undefined)
  const [selectedStage, setSelectedStage] = useState<number | undefined>(undefined)
  const [selectedRepresentativeLawyer, setSelectedRepresentativeLawyer] = useState<string[]>([])
  const [selectedInternalLawyer, setSelectedInternalLawyer] = useState<string[]>([])
  const [dateFrom, setDateFrom] = useState<string>("")
  const [dateTo, setDateTo] = useState<string>("")

  // Lawyer states
  const [responsibleLawyerTypes, setResponsibleLawyerTypes] = useState<LawyerOption[]>([])
  const [lawyerInternalTypes, setLawyerInternalTypes] = useState<LawyerOption[]>([])

  // Use refs to track if this is the initial render
  const isInitialRender = useRef(true)
  const searchTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  const router = useRouter()
  const searchParams = useSearchParams()

  // Fetch lawyers data
  useEffect(() => {
    const fetchLawyers = async () => {
      try {
        const response = await fetch(`${LAWYERS_ENDPOINT}?limit=100000`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${session?.user?.accessToken}`,
          },
        })

        if (!response.ok) {
          throw new Error(`Error: ${response.status} ${response.statusText}`)
        }

        const { data } = await response.json()

        const responsibleLawyerRoles = [
          Role.DIRECTOR_GENERAL_CEO,
          Role.GERENTE_GENERAL_COO,
          Role.DIRECTORA_AREA_LEGAL,
          Role.COORDINADOR_LEGAL,
          Role.ABOGADO_REPRESENTANTE,
        ]

        // Responsible Lawyers
        const filteredResponsibleLawyers = data.filter((user: any) =>
          user.roleUser.some((ru: any) => responsibleLawyerRoles.includes(ru.role.name)),
        )

        const responsibleLawyers = filteredResponsibleLawyers.map((user: any) => ({
          id: user.id.toString(),
          value: user.id.toString(),
          label: user.name,
        }))

        // Filter and map in separate steps to avoid TypeScript errors
        // Internal Lawyers
        const filteredInternalLawyers = data.filter((user: any) =>
          user.roleUser.some(
            (ru: any) => ru.role.name === Role.ASISTENTE_LEGAL || ru.role.name === Role.GERENTE_GENERAL_COO,
          ),
        )

        const internalLawyers = filteredInternalLawyers.map((user: any) => ({
          id: user.id.toString(),
          value: user.id.toString(),
          label: user.name,
        }))

        setLawyerInternalTypes(internalLawyers)
        setResponsibleLawyerTypes(responsibleLawyers)
      } catch (error) {
        console.error("Error fetching lawyers:", error)
        setLawyerInternalTypes([])
        setResponsibleLawyerTypes([])
      }
    }

    if (session?.user?.accessToken) {
      fetchLawyers()
    }
  }, [session?.user?.accessToken])

  // Format date for API
  const formatDateForApi = useCallback((dateString: string) => {
    if (!dateString) return undefined
    const date = new Date(dateString)
    return date.toISOString().split("T")[0]
  }, [])

  // Memoize the fetch function to prevent unnecessary recreations
  const fetchCases = useCallback(
    async (
      page: number,
      search: string,
      serviceId?: number,
      stageId?: number,
      fromDate?: string,
      toDate?: string,
      representativeLawyerIds?: string[],
      internalLawyerIds?: string[],
    ) => {
      try {
        setIsLoading(true)
        const url = new URL(`${CASES_ENDPOINT}`, window.location.origin)
        url.searchParams.append("page", page.toString())
        url.searchParams.append("limit", "10")

        if (search) {
          url.searchParams.append("search", search)
          setHasSearched(true)
        } else {
          setHasSearched(false)
        }

        if (serviceId !== undefined) {
          url.searchParams.append("servicesId", serviceId.toString())
        }

        if (stageId !== undefined) {
          url.searchParams.append("stageId", stageId.toString())
        }

        // Debug logs
        console.log("Frontend - Representative Lawyer IDs:", representativeLawyerIds)
        console.log("Frontend - Internal Lawyer IDs:", internalLawyerIds)

        // Fix: Handle both arrays and ensure they exist and have values
        if (representativeLawyerIds && representativeLawyerIds.length > 0) {
          // Ensure it's an array
          const repIds = Array.isArray(representativeLawyerIds) ? representativeLawyerIds : [representativeLawyerIds]
          repIds.forEach((id) => {
            if (id) {
              url.searchParams.append("representativeLawyerId", id.toString())
              console.log("Adding representativeLawyerId:", id)
            }
          })
        }

        if (internalLawyerIds && internalLawyerIds.length > 0) {
          // Ensure it's an array
          const intIds = Array.isArray(internalLawyerIds) ? internalLawyerIds : [internalLawyerIds]
          intIds.forEach((id) => {
            if (id) {
              url.searchParams.append("internalLawyerId", id.toString())
              console.log("Adding internalLawyerId:", id)
            }
          })
        }


        // Add date range parameters if they exist
        if (fromDate) {
          url.searchParams.append("fromDate", fromDate)
        }

        if (toDate) {
          url.searchParams.append("toDate", toDate)
        }

        console.log("Final URL:", url.toString())

        const response = await fetch(url.toString(), {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${session?.user?.accessToken}`,
          },
        })

        if (!response.ok) {
          const errorData = await response.json()
          console.error("Error response:", errorData)
          throw new Error(errorData.message || "Failed to fetch cases")
        }

        const result: ApiResponse = await response.json()
        setCases(result.data)
        setPagination({
          page: result.meta.page,
          limit: result.meta.limit,
          total: result.meta.total,
          totalPages: result.meta.totalPages,
        })
      } catch (error) {
        console.error("Error al cargar los casos:", error)
        toast.error(`Error al cargar los casos: ${(error as Error).message}`)
      } finally {
        setIsLoading(false)
      }
    },
    [session?.user?.accessToken],
  )

  // Load filters from URL on component mount - ONLY after lawyers data is loaded
  useEffect(() => {
    // Only load URL params if we have lawyer data loaded
    if (responsibleLawyerTypes.length === 0 && lawyerInternalTypes.length === 0) {
      return
    }

    const urlSearchTerm = searchParams.get("search") || ""
    const urlService = searchParams.get("service") ? Number.parseInt(searchParams.get("service")!) : undefined
    const urlStage = searchParams.get("stage") ? Number.parseInt(searchParams.get("stage")!) : undefined
    const urlRepLawyers = searchParams.get("repLawyers")
      ? searchParams.get("repLawyers")!.split(",").filter(Boolean)
      : []
    const urlIntLawyers = searchParams.get("intLawyers")
      ? searchParams.get("intLawyers")!.split(",").filter(Boolean)
      : []
    const urlDateFrom = searchParams.get("dateFrom") || ""
    const urlDateTo = searchParams.get("dateTo") || ""

    // Validate that lawyer IDs exist in our data
    const validRepLawyers = urlRepLawyers.filter((id) => responsibleLawyerTypes.some((lawyer) => lawyer.value === id))
    const validIntLawyers = urlIntLawyers.filter((id) => lawyerInternalTypes.some((lawyer) => lawyer.value === id))

    setSearchTerm(urlSearchTerm)
    setSelectedService(urlService)
    setSelectedStage(urlStage)
    setSelectedRepresentativeLawyer(validRepLawyers)
    setSelectedInternalLawyer(validIntLawyers)
    setDateFrom(urlDateFrom)
    setDateTo(urlDateTo)
  }, [searchParams, responsibleLawyerTypes, lawyerInternalTypes])

  // Initial fetch after lawyers are loaded and URL params are set
  useEffect(() => {
    if (isInitialRender.current && responsibleLawyerTypes.length > 0 && lawyerInternalTypes.length > 0) {
      // Get current URL params
      const urlSearchTerm = searchParams.get("search") || ""
      const urlService = searchParams.get("service") ? Number.parseInt(searchParams.get("service")!) : undefined
      const urlStage = searchParams.get("stage") ? Number.parseInt(searchParams.get("stage")!) : undefined
      const urlRepLawyers = searchParams.get("repLawyers")
        ? searchParams.get("repLawyers")!.split(",").filter(Boolean)
        : []
      const urlIntLawyers = searchParams.get("intLawyers")
        ? searchParams.get("intLawyers")!.split(",").filter(Boolean)
        : []
      const urlDateFrom = searchParams.get("dateFrom") || ""
      const urlDateTo = searchParams.get("dateTo") || ""

      fetchCases(
        1,
        urlSearchTerm,
        urlService,
        urlStage,
        formatDateForApi(urlDateFrom),
        formatDateForApi(urlDateTo),
        urlRepLawyers,
        urlIntLawyers,
      )
      isInitialRender.current = false
    }
  }, [responsibleLawyerTypes, lawyerInternalTypes, searchParams])

  // Function to update URL with current filters
  const updateURL = useCallback(
    (filters: {
      search?: string
      service?: number
      stage?: number
      repLawyers?: string[]
      intLawyers?: string[]
      dateFrom?: string
      dateTo?: string
    }) => {
      const params = new URLSearchParams()

      if (filters.search) params.set("search", filters.search)
      if (filters.service !== undefined) params.set("service", filters.service.toString())
      if (filters.stage !== undefined) params.set("stage", filters.stage.toString())

      // Ensure repLawyers is an array before calling join
      if (filters.repLawyers && Array.isArray(filters.repLawyers) && filters.repLawyers.length > 0) {
        params.set("repLawyers", filters.repLawyers.join(","))
      }

      // Ensure intLawyers is an array before calling join
      if (filters.intLawyers && Array.isArray(filters.intLawyers) && filters.intLawyers.length > 0) {
        params.set("intLawyers", filters.intLawyers.join(","))
      }

      if (filters.dateFrom) params.set("dateFrom", filters.dateFrom)
      if (filters.dateTo) params.set("dateTo", filters.dateTo)

      const newURL = params.toString() ? `?${params.toString()}` : window.location.pathname
      router.replace(newURL, { scroll: false })
    },
    [router],
  )

  // Handle search term changes with debouncing
  useEffect(() => {
    // Clear any existing timeout
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current)
    }

    // Set a new timeout
    searchTimeoutRef.current = setTimeout(() => {
      // Update URL with current filters
      updateURL({
        search: searchTerm,
        service: selectedService,
        stage: selectedStage,
        repLawyers: selectedRepresentativeLawyer,
        intLawyers: selectedInternalLawyer,
        dateFrom: dateFrom,
        dateTo: dateTo,
      })

      fetchCases(
        1,
        searchTerm,
        selectedService,
        selectedStage,
        formatDateForApi(dateFrom),
        formatDateForApi(dateTo),
        selectedRepresentativeLawyer,
        selectedInternalLawyer,
      )
      setCurrentPage(1) // Reset to first page when search term changes
    }, 500) // 500ms debounce

    // Cleanup function to clear the timeout if the component unmounts or searchTerm changes again
    return () => {
      if (searchTimeoutRef.current) {
        clearTimeout(searchTimeoutRef.current)
      }
    }
  }, [
    searchTerm,
    selectedService,
    selectedStage,
    selectedRepresentativeLawyer,
    selectedInternalLawyer,
    dateFrom,
    dateTo,
    updateURL,
  ])

  useEffect(() => {
    if (!isInitialRender.current) {
      fetchCases(
        currentPage,
        searchTerm,
        selectedService,
        selectedStage,
        formatDateForApi(dateFrom),
        formatDateForApi(dateTo),
        selectedRepresentativeLawyer,
        selectedInternalLawyer,
      )
    }
  }, [
    currentPage,
    searchTerm,
    selectedService,
    selectedStage,
    selectedRepresentativeLawyer,
    selectedInternalLawyer,
    dateFrom,
    dateTo,
    formatDateForApi,
  ])

  const handleClearSearch = useCallback(() => {
    setSearchTerm("")
    setSelectedService(undefined)
    setSelectedStage(undefined)
    setSelectedRepresentativeLawyer([])
    setSelectedInternalLawyer([])
    setHasSearched(false)
    setDateFrom("")
    setDateTo("")
    setCurrentPage(1) // Also reset current page

    // Clear URL params
    router.replace(window.location.pathname, { scroll: false })
  }, [router])

  const handleDelete = useCallback(
    async (id: number) => {
      try {
        const response = await fetch(`${CASES_ENDPOINT}/${id}`, {
          method: "DELETE",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${session?.user?.accessToken}`,
          },
        })

        if (!response.ok) {
          throw new Error("Failed to delete case")
        }

        toast.success("Caso eliminado correctamente")
        fetchCases(
          currentPage,
          searchTerm,
          selectedService,
          selectedStage,
          formatDateForApi(dateFrom),
          formatDateForApi(dateTo),
          selectedRepresentativeLawyer,
          selectedInternalLawyer,
        )
      } catch (error) {
        console.error("Error al eliminar el caso:", error)
        toast.error("Error al eliminar el caso")
      }
    },
    [
      session?.user?.accessToken,
      currentPage,
      searchTerm,
      selectedService,
      selectedStage,
      selectedRepresentativeLawyer,
      selectedInternalLawyer,
      formatDateForApi,
      dateFrom,
      dateTo,
    ],
  )

  const handlePageChange = useCallback((page: number) => {
    setCurrentPage(page)
  }, [])

  // Load view mode preference once on component mount
  useEffect(() => {
    const savedViewMode = localStorage.getItem("casosViewMode")
    if (savedViewMode === "card" || savedViewMode === "list") {
      setViewMode(savedViewMode as "card" | "list")
    }
  }, [])

  // Save view mode preference
  const handleViewModeChange = useCallback((mode: "card" | "list") => {
    setViewMode(mode)
    localStorage.setItem("casosViewMode", mode)
  }, [])

  // Check if any filters are active
  const hasActiveFilters = Boolean(
    searchTerm ||
    selectedService !== undefined ||
    selectedStage !== undefined ||
    (selectedRepresentativeLawyer && selectedRepresentativeLawyer.length > 0) ||
    (selectedInternalLawyer && selectedInternalLawyer.length > 0) ||
    dateFrom ||
    dateTo,
  )

  // Loading state
  if (isLoading && cases.length === 0 && !hasSearched) {
    return (
      <div>
        <div className="flex h-full flex-1 flex-col justify-center items-center gap-4 rounded-xl p-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    )
  }

  // Empty state - only show for initial load with no data and no search
  if (cases.length === 0 && !hasActiveFilters && !isLoading) {
    return (
      <DataNotFound
        error={"No hay casos disponibles."}
        description={"No se encontraron casos en la base de datos."}
        buttonText={"Crear caso"}
        icon={<Plus className="mr-2 h-4 w-4" />}
        pathname="/admin/legal-cases/new"
      />
    )
  }

  return (
    <div>
      <div className="flex flex-col gap-6 mb-2">
        <CasesHeader title="Gestor de casos" />

        <CasesFilters
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          selectedService={selectedService}
          setSelectedService={setSelectedService}
          selectedStage={selectedStage}
          setSelectedStage={setSelectedStage}
          selectedRepresentativeLawyer={selectedRepresentativeLawyer}
          setSelectedRepresentativeLawyer={setSelectedRepresentativeLawyer}
          selectedInternalLawyer={selectedInternalLawyer}
          setSelectedInternalLawyer={setSelectedInternalLawyer}
          dateFrom={dateFrom}
          setDateFrom={setDateFrom}
          dateTo={dateTo}
          setDateTo={setDateTo}
          hasActiveFilters={hasActiveFilters}
          handleClearSearch={handleClearSearch}
          viewMode={viewMode}
          handleViewModeChange={handleViewModeChange}
          responsibleLawyerTypes={responsibleLawyerTypes}
          lawyerInternalTypes={lawyerInternalTypes}
        />
      </div>

      {/* Show loading overlay when refreshing data */}
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-white/50 z-10">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      )}

      {viewMode === "card" ? (
        <CasesCardView cases={cases} hasActiveFilters={hasActiveFilters} handleClearSearch={handleClearSearch} />
      ) : (
        <CasesListView
          cases={cases}
          hasActiveFilters={hasActiveFilters}
          handleClearSearch={handleClearSearch}
          handleDelete={handleDelete}
        />
      )}

      <Pagination
        currentPage={pagination.page}
        totalPages={pagination.totalPages}
        totalItems={pagination.total}
        itemsPerPage={pagination.limit}
        onPageChange={handlePageChange}
      />
    </div>
  )
}

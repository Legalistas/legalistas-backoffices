"use client"

import type React from "react"

import { useCallback, useEffect, useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { servicesType, stageCases } from "@/lib/constant"
import Button from "@/components/ui/button/Button"
import { Modal } from "@/components/ui/modal/Modal"
import { Loader2, Search, UserPlus, ChevronDown, AlertCircle, X, Check } from "lucide-react"
import Label from "@/components/ui/label/Label"
import Input from "@/components/ui/input/Input"
import { Role } from "@/constant/user"
import { CASES_ENDPOINT, LAWYERS_ENDPOINT, USERS_ENDPOINT } from "@/constant/api-endpoints"
import { useSession } from "next-auth/react"
import Switch from "@/components/ui/switch/Switch"
import { toast } from "sonner"

interface Customer {
    id: number
    name: string
    email: string
    phone?: string
    roleUser: Array<{
        role: {
            id: number
            name: string
        }
    }>
    crmLeads?: Array<{
        id: number
        sellerId: number
        internalLawyerId: number
        responsibleLawyerId: number
        servicesId: number
        sourceChannelId: number
        status: string
        statusDate: string | null
        columnId: number
        notes: string
        documentationComplete: boolean
        createdAt: string
        updatedAt: string
        userId: number
        converted: boolean
    }>
}

export default function AddNewCase() {
    const router = useRouter()
    const { data: session } = useSession()

    // Referencias para los selectores
    const serviceSelectRef = useRef<HTMLDivElement>(null)
    const stageSelectRef = useRef<HTMLDivElement>(null)
    const internalLawyerSelectRef = useRef<HTMLDivElement>(null)
    const responsibleLawyersSelectRef = useRef<HTMLDivElement>(null)
    const customerSelectRef = useRef<HTMLDivElement>(null)
    const searchInputRef = useRef<HTMLInputElement>(null)

    // Estados para los selects
    const [isServiceSelectOpen, setIsServiceSelectOpen] = useState(false)
    const [isStageSelectOpen, setIsStageSelectOpen] = useState(false)

    // Estado para el modal de nuevo cliente
    const [isModalOpen, setIsModalOpen] = useState(false)

    // Estados para el multiselect de clientes
    const [customerSearchTerm, setCustomerSearchTerm] = useState("")
    const [showCustomerSuggestions, setShowCustomerSuggestions] = useState(false)
    const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null)
    const [filteredCustomers, setFilteredCustomers] = useState<Customer[]>([])
    const [isLoadingCustomers, setIsLoadingCustomers] = useState(false)

    // Estado del formulario
    const [formData, setFormData] = useState({
        number: "",
        title: "",
        customerId: null as number | null,
        isActive: true,
        isArchived: false,
        stageId: 1,
        servicesId: 1,
        responsibleLawyerId: "",
        internalLawyerId: "",
        leadId: null as number | null, // 👈 nuevo campo
    })

    // Estado para el formulario de nuevo cliente
    const [newCustomer, setNewCustomers] = useState({
        name: "",
        email: "",
        phone: "",
        address: "",
    })

    const [isSubmitting, setIsSubmitting] = useState(false)
    const [error, setError] = useState<string | null>(null)

    // User Lawyer
    const [isLoading, setIsLoading] = useState(true)
    const [responsibleLawyers, setResponsibleLawyers] = useState<any[]>([])
    const [internalLawyers, setInternalLawyers] = useState<any[]>([])
    const [customers, setCustomers] = useState<Customer[]>([])

    const [selectedLead, setSelectedLead] = useState<any>(null)
    const [showLeadSelector, setShowLeadSelector] = useState(false)
    const [availableLeads, setAvailableLeads] = useState<any[]>([])

    // Fetch customers with role ID 34 only
    const fetchCustomers = useCallback(async () => {
        if (!session?.user?.accessToken) return

        try {
            setIsLoadingCustomers(true)
            const response = await fetch(`${USERS_ENDPOINT}?limit=100000`, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${session?.user?.accessToken}`,
                },
            })

            if (!response.ok) {
                throw new Error(`Error fetching customers: ${response.status}`)
            }

            const data = await response.json()
            // Filtrar solo usuarios con role ID 34 y eliminar duplicados
            const customersWithRole34 = Array.isArray(data.data)
                ? data.data
                    .filter((customer: Customer) => customer.roleUser?.some((ru) => ru.role.id === 34))
                    .filter(
                        (customer: Customer, index: number, self: Customer[]) =>
                            index === self.findIndex((c) => c.id === customer.id),
                    )
                : []

            setCustomers(customersWithRole34)
            console.log(`Cargados ${customersWithRole34.length} clientes con role ID 34`)
        } catch (error) {
            console.error("Error fetching customers:", error)
            setError("Error al cargar los clientes")
        } finally {
            setIsLoadingCustomers(false)
        }
    }, [session?.user?.accessToken])

    // Filter customers based on search term
    useEffect(() => {
        if (customerSearchTerm.trim() === "") {
            setFilteredCustomers([])
            return
        }

        // Remove this condition to allow showing results with just 1 character
        // if (customerSearchTerm.length < 2) {
        //     setFilteredCustomers([])
        //     return
        // }

        const filtered = customers.filter((customer) => {
            // Check if customer has non-converted leads
            const hasNonConvertedLeads = customer.crmLeads?.some((lead) => !lead.converted) || false

            return (
                // Remove the hasNonConvertedLeads condition to show all customers
                // hasNonConvertedLeads &&
                customer.name.toLowerCase().includes(customerSearchTerm.toLowerCase()) ||
                customer.email.toLowerCase().includes(customerSearchTerm.toLowerCase())
            )
        })

        setFilteredCustomers(filtered)
    }, [customerSearchTerm, customers])

    const fetchDataLawyer = useCallback(async () => {
        try {
            setIsLoading(true)
            setError(null)
            const response = await fetch(`${LAWYERS_ENDPOINT}?limit=100000`, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${session?.user?.accessToken}`,
                },
            })
            const data = await response.json()

            if (data && data.data) {
                // Separar abogados por rol
                const responsible = data.data.filter((lawyer: any) =>
                    lawyer.roleUser?.some(
                        (ru: any) =>
                            ru.role?.name === Role.DIRECTOR_GENERAL_CEO ||
                            ru.role?.name === Role.GERENTE_GENERAL_COO ||
                            ru.role?.name === Role.ABOGADO_REPRESENTANTE,
                    ),
                )

                const internal = data.data.filter((lawyer: any) =>
                    lawyer.roleUser?.some(
                        (ru: any) =>
                            ru.role?.name === Role.ASISTENTE_LEGAL ||
                            ru.role?.name === Role.GERENTE_GENERAL_COO ||
                            ru.role?.name === Role.ASISTENTE_LEGAL,
                    ),
                )

                setResponsibleLawyers(responsible)
                setInternalLawyers(internal)
            }
        } catch (error) {
            console.error("Error fetching data:", error)
            setError("Error al cargar los datos de abogados")
        } finally {
            setIsLoading(false)
        }
    }, [session?.user?.accessToken])

    // Cargar datos al montar el componente
    useEffect(() => {
        fetchDataLawyer()
        fetchCustomers()
    }, [fetchDataLawyer, fetchCustomers])

    // Handle customer selection
    const handleSelectCustomer = (customer: Customer, specificLead?: any) => {
        if (selectedCustomer?.id === customer.id) {
            return
        }

        const nonConvertedLeads = customer.crmLeads?.filter((lead) => !lead.converted) || []

        // If customer has multiple non-converted leads and no specific lead is provided
        if (nonConvertedLeads.length > 1 && !specificLead) {
            setAvailableLeads(nonConvertedLeads)
            setShowLeadSelector(true)
            setSelectedCustomer(customer)
            setFormData((prev) => ({
                ...prev,
                customerId: customer.id,
            }))

            // Update title
            setFormData((prev) => ({
                ...prev,
                title: `Caso de ${customer.name}`,
            }))

            setCustomerSearchTerm("")
            setShowCustomerSuggestions(false)
            return
        }

        // Use specific lead or first available lead
        const leadToUse = specificLead || nonConvertedLeads[0]

        setSelectedCustomer(customer)
        setFormData((prev) => ({
            ...prev,
            customerId: customer.id,
        }))

        // Auto-populate form fields if customer has non-converted leads
        if (leadToUse) {
            setFormData((prev) => ({
                ...prev,
                internalLawyerId: leadToUse.internalLawyerId.toString(),
                responsibleLawyerId: leadToUse.responsibleLawyerId.toString(),
                servicesId: leadToUse.servicesId,
                customerId: customer.id,
                leadId: leadToUse.id, // 👈 acá también
            }))
            setSelectedLead(leadToUse)
        }

        // Update title
        setFormData((prev) => ({
            ...prev,
            title: `Caso de ${customer.name}`,
        }))

        setCustomerSearchTerm("")
        setShowCustomerSuggestions(false)
        // Focus back to input after selection
        setTimeout(() => {
            searchInputRef.current?.focus()
        }, 100)
    }

    const handleSelectLead = (lead: any) => {
        setFormData((prev) => ({
            ...prev,
            internalLawyerId: lead.internalLawyerId.toString(),
            responsibleLawyerId: lead.responsibleLawyerId.toString(),
            servicesId: lead.servicesId,
            leadId: lead.id, // 👈 aquí
        }))
        setSelectedLead(lead)
        setShowLeadSelector(false)
        setAvailableLeads([])
    }

    // Remove customer from selection
    const handleRemoveCustomer = () => {
        setSelectedCustomer(null)
        setFormData((prev) => ({
            ...prev,
            customerId: null,
            title: "",
        }))

        // Focus back to input after removal
        setTimeout(() => {
            searchInputRef.current?.focus()
        }, 100)
    }

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target
        setFormData((prev) => ({ ...prev, [name]: value }))
    }

    const handleSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const { name, value } = e.target
        setFormData((prev) => ({ ...prev, [name]: value }))
    }

    // Manejadores para los selects
    const handleServicesIdChange = (value: number) => {
        console.log("Tipo de servicio seleccionado:", value)
        setFormData((prev) => ({ ...prev, servicesId: value }))
        setIsServiceSelectOpen(false)
    }

    // Handler for stageId
    const handleStageIdChange = (value: number) => {
        console.log("Etapa seleccionada:", value)
        setFormData((prev) => ({ ...prev, stageId: value }))
        setIsStageSelectOpen(false)
    }

    // Separate handler for the isActive switch (now boolean)
    const handleIsActiveChange = (checked: boolean) => {
        console.log("isActive cambiado:", checked)
        setFormData((prev) => ({ ...prev, isActive: checked }))
    }

    // Handler for isArchived
    const handleIsArchivedChange = (checked: boolean) => {
        console.log("isArchived cambiado:", checked)
        setFormData((prev) => ({ ...prev, isArchived: checked }))
    }

    const handleCustomerSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setCustomerSearchTerm(e.target.value)
        setShowCustomerSuggestions(true)
    }

    const handleNuevoClienteChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target
        setNewCustomers((prev) => ({ ...prev, [name]: value }))
    }

    const handleCrearCliente = (e: React.MouseEvent) => {
        e.preventDefault()

        // Aquí iría la lógica para crear el cliente en la base de datos
        console.log("Creando cliente:", newCustomer)

        // Simulamos la creación exitosa
        const nuevoCliente: Customer = {
            id: Date.now(),
            name: newCustomer.name,
            email: newCustomer.email,
            phone: newCustomer.phone,
            roleUser: [{ role: { id: 34, name: "customer" } }],
            crmLeads: undefined,
        }

        // Agregamos el nuevo cliente a la selección
        handleSelectCustomer(nuevoCliente)

        // Cerramos el modal y limpiamos el formulario
        setIsModalOpen(false)
        setNewCustomers({
            name: "",
            email: "",
            phone: "",
            address: "",
        })

        toast.success("Cliente creado y agregado al caso")
    }

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()

        if (!formData.title.trim()) {
            toast.error("Por favor, ingrese un título para el caso")
            return
        }

        if (!formData.customerId) {
            toast.error("Por favor, seleccione al menos un cliente")
            return
        }

        if (!formData.responsibleLawyerId && !formData.internalLawyerId) {
            toast.error("Por favor, seleccione al menos un abogado")
            return
        }

        try {
            setIsSubmitting(true)
            setError(null)

            const nuevoCaso = {
                createdByUserId: session?.user?.id,
                number: formData.number || String(Math.floor(Math.random() * 10000) + 1),
                title: formData.title,
                isActive: formData.isActive,
                isArchived: formData.isArchived,
                status: "IN_PROGRESS",
                stageId: formData.stageId,
                servicesId: formData.servicesId,
                userId: formData.customerId,
                leadId: formData.leadId, // 👈 aquí lo agregás
                responsibleLawyerId: formData.responsibleLawyerId
                    ? Number.parseInt(formData.responsibleLawyerId, 10)
                    : undefined,
                internalLawyerId: formData.internalLawyerId ? Number.parseInt(formData.internalLawyerId, 10) : undefined,
                files: [],
            }

            console.log("Enviando caso:", nuevoCaso)
            const response = await fetch(`${CASES_ENDPOINT}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${session?.user?.accessToken}`,
                },
                body: JSON.stringify(nuevoCaso),
            })

            if (!response.ok) {
                const errorData = await response.json()
                throw new Error(errorData.message || "Failed to create case")
            }

            const data = await response.json()
            console.log("Caso creado:", data)
            toast.success("Caso creado exitosamente!")
            router.push("/admin/legal-cases")
        } catch (err) {
            console.error("Error creating case:", err)
            setError(`Failed to create case: ${err instanceof Error ? err.message : "Unknown error"}`)
        } finally {
            setIsSubmitting(false)
        }
    }

    // Función para abrir el modal
    const openModal = (e: React.MouseEvent) => {
        e.preventDefault()
        console.log("Abriendo modal de nuevo cliente")
        setIsModalOpen(true)
    }

    // Función para cerrar los selectores al hacer clic fuera de ellos
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (serviceSelectRef.current && !serviceSelectRef.current.contains(event.target as Node) && isServiceSelectOpen) {
                setIsServiceSelectOpen(false)
            }

            if (stageSelectRef.current && !stageSelectRef.current.contains(event.target as Node) && isStageSelectOpen) {
                setIsStageSelectOpen(false)
            }

            // Only close customer suggestions if clicking outside AND not on the search input
            if (
                customerSelectRef.current &&
                !customerSelectRef.current.contains(event.target as Node) &&
                searchInputRef.current !== event.target
            ) {
                setShowCustomerSuggestions(false)
            }
        }

        document.addEventListener("mousedown", handleClickOutside)
        return () => {
            document.removeEventListener("mousedown", handleClickOutside)
        }
    }, [isServiceSelectOpen, isStageSelectOpen])

    // Add this after the fetchCustomers function completes
    useEffect(() => {
        console.log("Loaded customers:", customers.length)
    }, [customers])

    return (
        <>
            <div className="mx-auto max-w-2xl z-0">
                <div className="overflow-hidden rounded-lg border border-gray-200 bg-white shadow">
                    <div className="border-b border-gray-200 bg-white px-6 py-4">
                        <div className="flex justify-between items-center mb-1">
                            <h2 className="text-xl font-semibold text-gray-900">Crear nuevo caso</h2>
                            <div className="flex items-center gap-4">
                                <div className="flex items-center gap-2">
                                    <span className="text-sm text-gray-700">{formData.isArchived ? "Archivado" : "No archivado"}</span>
                                    <Switch
                                        id="switch-archive"
                                        label=""
                                        defaultChecked={formData.isArchived}
                                        onChange={handleIsArchivedChange}
                                        color="blue"
                                    />
                                </div>
                                <div className="flex items-center gap-2">
                                    <span className="text-sm text-gray-700">{formData.isActive ? "Activo" : "Inactivo"}</span>
                                    <Switch
                                        id="switch-case"
                                        label=""
                                        defaultChecked={formData.isActive}
                                        onChange={handleIsActiveChange}
                                        color="blue"
                                    />
                                </div>
                            </div>
                        </div>
                        <p className="mt-1 text-sm text-gray-500">Complete la información para crear un nuevo caso</p>
                    </div>
                    {error && (
                        <div className="mx-6 mt-4 rounded-md bg-red-50 p-4">
                            <div className="flex">
                                <div className="flex-shrink-0">
                                    <AlertCircle className="h-5 w-5 text-red-400" />
                                </div>
                                <div className="ml-3">
                                    <p className="text-sm text-red-700">{error}</p>
                                </div>
                            </div>
                        </div>
                    )}
                    <form onSubmit={handleSubmit}>
                        <div className="space-y-4 px-6 py-4">
                            {/* Multiselect de Clientes con chips dentro del input */}
                            <div className="space-y-2">
                                <label htmlFor="cliente-search" className="block text-sm font-medium text-gray-700">
                                    Clientes
                                </label>

                                <div className="flex items-center gap-2">
                                    <div className="relative w-full" ref={customerSelectRef}>
                                        {/* Input container con chips internos */}
                                        <div className="relative w-full min-h-[42px] rounded-md border border-gray-300 bg-white shadow-sm focus-within:border-blue-500 focus-within:ring-1 focus-within:ring-blue-500">
                                            <div className="flex flex-wrap items-center gap-1 p-2">
                                                {/* Selected customers chips */}
                                                {selectedCustomer && (
                                                    <div
                                                        key={selectedCustomer.id}
                                                        className="inline-flex items-center gap-1 px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full"
                                                    >
                                                        <span className="max-w-[120px] truncate">{selectedCustomer.name}</span>
                                                        <button
                                                            type="button"
                                                            onClick={() => handleRemoveCustomer()}
                                                            className="hover:bg-blue-200 rounded-full p-0.5 flex-shrink-0"
                                                        >
                                                            <X className="w-3 h-3" />
                                                        </button>
                                                    </div>
                                                )}

                                                {/* Search input */}
                                                <div className="flex-1 min-w-[120px] relative">
                                                    <input
                                                        ref={searchInputRef}
                                                        type="text"
                                                        id="cliente-search"
                                                        className="w-full border-0 bg-transparent pl-2 pr-8 py-1 text-sm placeholder-gray-400 focus:outline-none focus:ring-0"
                                                        placeholder={selectedCustomer ? "" : "Buscar cliente..."}
                                                        value={customerSearchTerm}
                                                        onChange={handleCustomerSearchChange}
                                                        onFocus={() => setShowCustomerSuggestions(true)}
                                                    />
                                                    <div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                                                        {isLoadingCustomers ? (
                                                            <Loader2 className="w-4 h-4 text-gray-400 animate-spin" />
                                                        ) : (
                                                            <Search className="w-4 h-4 text-gray-400" />
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        {/* Suggestions dropdown */}
                                        {showCustomerSuggestions && filteredCustomers.length > 0 && (
                                            <div className="absolute z-10 mt-1 w-full max-h-60 overflow-auto rounded-md border border-gray-200 bg-white py-1 shadow-lg">
                                                {filteredCustomers.map((customer) => {
                                                    const isSelected = selectedCustomer?.id === customer.id
                                                    const nonConvertedLeads = customer.crmLeads?.filter((lead) => !lead.converted) || []
                                                    return (
                                                        <div key={customer.id}>
                                                            <div
                                                                className={`cursor-pointer px-3 py-2 text-sm hover:bg-gray-100 flex items-center justify-between ${isSelected ? "bg-blue-50" : ""
                                                                    }`}
                                                                onClick={() => handleSelectCustomer(customer)}
                                                            >
                                                                <div className="flex-1">
                                                                    <div className="font-medium">{customer.name}</div>
                                                                    <div className="text-xs text-gray-500">{customer.email}</div>
                                                                    {nonConvertedLeads.length > 0 && (
                                                                        <div className="text-xs text-blue-600 mt-1">
                                                                            {nonConvertedLeads.length} oportunidad{nonConvertedLeads.length > 1 ? "es" : ""}{" "}
                                                                            disponible{nonConvertedLeads.length > 1 ? "s" : ""}
                                                                        </div>
                                                                    )}
                                                                </div>
                                                                {isSelected && <Check className="w-4 h-4 text-blue-600" />}
                                                            </div>

                                                            {/* Show individual leads if customer has multiple */}
                                                            {nonConvertedLeads.length > 1 && (
                                                                <div className="ml-4 border-l-2 border-gray-200">
                                                                    {nonConvertedLeads.map((lead, index) => (
                                                                        <div
                                                                            key={lead.id}
                                                                            className="cursor-pointer px-3 py-2 text-xs hover:bg-blue-50 border-l-2 border-transparent hover:border-blue-300"
                                                                            onClick={(e) => {
                                                                                e.stopPropagation()
                                                                                handleSelectCustomer(customer, lead)
                                                                            }}
                                                                        >
                                                                            <div className="text-gray-700">Oportunidad #{lead.id}</div>
                                                                            <div className="text-gray-500">Estado: {lead.status}</div>
                                                                            <div className="text-gray-500">Servicio ID: {lead.servicesId}</div>
                                                                        </div>
                                                                    ))}
                                                                </div>
                                                            )}
                                                        </div>
                                                    )
                                                })}
                                            </div>
                                        )}
                                    </div>

                                    <button
                                        type="button"
                                        className="inline-flex items-center py-2 px-3 text-sm font-medium text-white bg-blue-700 rounded-lg border border-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 flex-shrink-0"
                                        onClick={openModal}
                                    >
                                        <UserPlus className="w-4 h-4 me-1" />
                                        Nuevo
                                    </button>
                                </div>
                            </div>

                            <div className="space-y-2">
                                <div className="flex gap-4">
                                    <div className="w-3/4 space-y-2">
                                        <label htmlFor="title" className="block text-sm font-medium text-gray-700">
                                            Titulo
                                        </label>
                                        <input
                                            id="title"
                                            name="title"
                                            placeholder="Ingrese título del caso"
                                            value={formData.title}
                                            onChange={handleChange}
                                            required
                                            className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                                        />
                                    </div>
                                    <div className="w-1/4 space-y-2">
                                        <label htmlFor="number" className="block text-sm font-medium text-gray-700">
                                            Nº de caso
                                        </label>
                                        <input
                                            id="number"
                                            name="number"
                                            placeholder="Auto"
                                            value={formData.number}
                                            onChange={handleChange}
                                            className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                                        />
                                    </div>
                                </div>
                            </div>

                            {/* Tipo de Servicio y Estado del Caso en layout 1/2 + 1/2 */}
                            <div className="flex gap-4">
                                <div className="w-1/2 space-y-2">
                                    <label htmlFor="servicesId" className="block text-sm font-medium text-gray-700">
                                        Tipo de Servicio
                                    </label>
                                    <div className="relative" ref={serviceSelectRef}>
                                        <select
                                            id="servicesId"
                                            name="servicesId"
                                            value={formData.servicesId}
                                            onChange={(e) => handleServicesIdChange(Number(e.target.value))}
                                            className="w-full appearance-none rounded-md border border-gray-300 bg-white px-3 py-2 text-sm shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                                        >
                                            {servicesType.map((type) => (
                                                <option key={type.id} value={type.value}>
                                                    {type.label}
                                                </option>
                                            ))}
                                        </select>
                                        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                            <ChevronDown className="h-4 w-4" />
                                        </div>
                                    </div>
                                </div>

                                <div className="w-1/2 space-y-2">
                                    <label htmlFor="stageId" className="block text-sm font-medium text-gray-700">
                                        Etapa del Caso
                                    </label>
                                    <div className="relative" ref={stageSelectRef}>
                                        <select
                                            id="stageId"
                                            name="stageId"
                                            value={formData.stageId}
                                            onChange={(e) => handleStageIdChange(Number(e.target.value))}
                                            className="w-full appearance-none rounded-md border border-gray-300 bg-white px-3 py-2 text-sm shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                                        >
                                            {stageCases.map((stage, index) => (
                                                <option key={index} value={stage.value}>
                                                    {stage.label}
                                                </option>
                                            ))}
                                        </select>
                                        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                            <ChevronDown className="h-4 w-4" />
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {isLoading ? (
                                <div className="flex items-center justify-center mt-4">
                                    <Loader2 className="mr-2 -ml-1 h-4 w-4 animate-spin text-blue-500" />
                                    <span className="text-sm text-gray-500">Cargando abogados...</span>
                                </div>
                            ) : (
                                <div className="flex gap-4">
                                    <div className="w-1/2 space-y-2">
                                        <label htmlFor="responsibleLawyerId" className="block text-sm font-medium text-gray-700">
                                            Abogado Responsable
                                        </label>
                                        <div className="relative" ref={responsibleLawyersSelectRef}>
                                            <select
                                                id="responsibleLawyerId"
                                                name="responsibleLawyerId"
                                                value={formData.responsibleLawyerId}
                                                onChange={handleSelectChange}
                                                className="w-full appearance-none rounded-md border border-gray-300 bg-white px-3 py-2 text-sm shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                                            >
                                                <option value="">Seleccione un abogado responsable</option>
                                                {responsibleLawyers.map((lawyer) => (
                                                    <option key={lawyer.id} value={lawyer.id}>
                                                        {lawyer.id}-{lawyer.name}
                                                    </option>
                                                ))}
                                            </select>
                                            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                                <ChevronDown className="h-4 w-4" />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="w-1/2 space-y-2">
                                        <label htmlFor="internalLawyerId" className="block text-sm font-medium text-gray-700">
                                            Abogado Interno
                                        </label>
                                        <div className="relative" ref={internalLawyerSelectRef}>
                                            <select
                                                id="internalLawyerId"
                                                name="internalLawyerId"
                                                value={formData.internalLawyerId}
                                                onChange={handleSelectChange}
                                                className="w-full appearance-none rounded-md border border-gray-300 bg-white px-3 py-2 text-sm shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                                            >
                                                <option value="">Seleccione un abogado externo</option>
                                                {internalLawyers.map((lawyer) => (
                                                    <option key={lawyer.id} value={lawyer.id}>
                                                        {lawyer.name}
                                                    </option>
                                                ))}
                                            </select>
                                            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                                <ChevronDown className="h-4 w-4" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                        <div className="flex justify-between border-t border-gray-200 bg-gray-50 px-6 py-4">
                            <Button
                                variant="outline"
                                onClick={() => router.back()}
                                className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                            >
                                Cancel
                            </Button>
                            <Button
                                disabled={isSubmitting}
                                className={`rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${isSubmitting ? "opacity-70 cursor-not-allowed" : ""}`}
                            >
                                {isSubmitting ? (
                                    <>
                                        <Loader2 className="mr-2 -ml-1 h-4 w-4 animate-spin text-white" />
                                        Creando...
                                    </>
                                ) : (
                                    "Crear caso"
                                )}
                            </Button>
                        </div>
                    </form>
                </div>
            </div>
            {/* Modal para crear nuevo cliente usando el componente personalizado */}
            <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} className="max-w-md mx-auto p-6">
                <div className="mb-6">
                    <h2 className="text-xl font-semibold text-gray-900">Crear nuevo cliente</h2>
                    <p className="mt-1 text-sm text-gray-500">Complete la información del nuevo cliente</p>
                </div>

                <div className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="name">Nombre completo</Label>
                        <Input
                            id="name"
                            name="name"
                            defaultValue={newCustomer.name}
                            onChange={handleNuevoClienteChange}
                            placeholder="Ingrese el nombre completo"
                        />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input
                            id="email"
                            name="email"
                            type="email"
                            defaultValue={newCustomer.email}
                            onChange={handleNuevoClienteChange}
                            placeholder="ejemplo@correo.com"
                        />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="phone">Teléfono</Label>
                        <Input
                            id="phone"
                            name="phone"
                            defaultValue={newCustomer.phone}
                            onChange={handleNuevoClienteChange}
                            placeholder="11-1234-5678"
                        />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="address">Dirección</Label>
                        <Input
                            id="address"
                            name="address"
                            defaultValue={newCustomer.address}
                            onChange={handleNuevoClienteChange}
                            placeholder="Av. Ejemplo 123, Ciudad"
                        />
                    </div>
                </div>

                <div className="mt-6 flex justify-end gap-3">
                    <button
                        type="button"
                        className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50"
                        onClick={() => setIsModalOpen(false)}
                    >
                        Cancelar
                    </button>
                    <button
                        type="button"
                        className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700"
                        onClick={handleCrearCliente}
                    >
                        Crear cliente
                    </button>
                </div>
            </Modal>
            {/* Modal para seleccionar oportunidad */}
            <Modal isOpen={showLeadSelector} onClose={() => setShowLeadSelector(false)} className="max-w-lg mx-auto p-6">
                <div className="mb-6">
                    <h2 className="text-xl font-semibold text-gray-900">Seleccionar Oportunidad</h2>
                    <p className="mt-1 text-sm text-gray-500">
                        Este cliente tiene múltiples oportunidades. Seleccione una para continuar.
                    </p>
                </div>

                <div className="space-y-3 max-h-60 overflow-y-auto">
                    {availableLeads.map((lead) => (
                        <div
                            key={lead.id}
                            className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 hover:bg-blue-50 cursor-pointer transition-colors"
                            onClick={() => handleSelectLead(lead)}
                        >
                            <div className="flex justify-between items-start mb-2">
                                <h3 className="font-medium text-gray-900">Oportunidad #{lead.id}</h3>
                                <span
                                    className={`px-2 py-1 text-xs rounded-full ${lead.status === "IN_PROGRESS" ? "bg-yellow-100 text-yellow-800" : "bg-gray-100 text-gray-800"
                                        }`}
                                >
                                    {lead.status}
                                </span>
                            </div>
                            <div className="space-y-1 text-sm text-gray-600">
                                <div>Servicio ID: {lead.servicesId}</div>
                                <div>Abogado Interno ID: {lead.internalLawyerId}</div>
                                <div>Abogado Responsable ID: {lead.responsibleLawyerId}</div>
                                <div>Creado: {new Date(lead.createdAt).toLocaleDateString()}</div>
                                {lead.notes && <div>Notas: {lead.notes}</div>}
                            </div>
                        </div>
                    ))}
                </div>

                <div className="mt-6 flex justify-end gap-3">
                    <button
                        type="button"
                        className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50"
                        onClick={() => {
                            setShowLeadSelector(false)
                            setAvailableLeads([])
                            // Remove the customer that was just added
                            if (selectedCustomer) {
                                handleRemoveCustomer()
                            }
                        }}
                    >
                        Cancelar
                    </button>
                </div>
            </Modal>
        </>
    )
}

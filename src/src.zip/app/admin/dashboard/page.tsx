import React from "react";
import { Metadata } from "next";
import DashboardComponent from "@/components/dashboard/DashboardComponent";

export const metadata: Metadata = {
    title: "Next.js Analytics Dashboard | TailAdmin - Next.js Dashboard Template",
    description:
        "This is Next.js Analytics Dashboard page for TailAdmin - Next.js Tailwind CSS Admin Dashboard Template",
};

export default function Dashboard() {
    return <DashboardComponent />;
}

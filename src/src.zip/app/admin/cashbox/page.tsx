export default function CashBoxPage() {
    return <>Estamos trabajando</>
}
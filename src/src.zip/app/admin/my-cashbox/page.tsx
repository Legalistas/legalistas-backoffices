export default function MyCashboxPage() {
    return <>Estamos trabajando</>
}
"use client"

import { useEffect, useState } from "react"
import dynamic from "next/dynamic"
import { CalendarDays, TrendingUp, TrendingDown, Clock, Target } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card/Card"
import Badge from "@/components/ui/badge/Badge"
import { STATISTICS_CRM_DASHBOARD_ENDPOINT } from "@/constant/api-endpoints"
import { useSession } from "next-auth/react"

// Importar ApexCharts dinámicamente para evitar problemas de SSR
const Chart = dynamic(() => import("react-apexcharts"), { ssr: false })

// Datos de ejemplo
const monthlyData = [
    { month: "Ene", ganadas: 45, perdidas: 12 },
    { month: "Feb", ganadas: 52, perdidas: 8 },
    { month: "Mar", ganadas: 38, perdidas: 15 },
    { month: "Abr", ganadas: 61, perdidas: 10 },
    { month: "May", ganadas: 55, perdidas: 14 },
    { month: "Jun", ganadas: 67, perdidas: 9 },
]

const channelData = [
    { name: "Web", value: 35 },
    { name: "Email", value: 25 },
    { name: "Redes Sociales", value: 20 },
    { name: "Referidos", value: 15 },
    { name: "Otros", value: 5 },
]


export default function ReportSalesPage() {
    const { data: session } = useSession()
    const [timeframe, setTimeframe] = useState("day") // ✅ Solo una variable para el filtro de tiempo
    const [yearFilter, setYearFilter] = useState("2024")
    const [data, setData] = useState({
        casesCreated: 0,
        casesWon: 0,
        casesLost: 0,
        casesInProgress: 0,
        tasaConversion: 0,
        tendenciaCreadas: 0,
        tendenciaGanadas: 0,
        tendenciaPerdidas: 0,
        tendenciaConversion: 0,
    })
    const [channelData, setChannelData] = useState({
        monthlySourceData: [],
        monthlySocialData: [],
    })
    const [loading, setLoading] = useState(false)

    // Configuración para el gráfico de barras (Ganadas vs Perdidas)
    const barChartOptions = {
        chart: {
            type: "bar" as const,
            height: 300,
            stacked: true,
            toolbar: {
                show: false,
            },
            background: "transparent",
        },
        plotOptions: {
            bar: {
                horizontal: false,
                borderRadius: 10,
                borderRadiusApplication: "end" as "end" | "around" | undefined,
                borderRadiusWhenStacked: "last" as "all" | "last" | undefined,
                dataLabels: {
                    total: {
                        enabled: true,
                        style: {
                            fontSize: "13px",
                            fontWeight: 900,
                        },
                    },
                },
            },
        },
        dataLabels: {
            enabled: false,
        },
        stroke: {
            show: true,
            width: 2,
            colors: ["transparent"],
        },
        xaxis: {
            categories: monthlyData.map((item) => item.month),
            axisBorder: {
                show: false,
            },
            axisTicks: {
                show: false,
            },
            labels: {
                style: {
                    colors: "#6b7280",
                    fontSize: "12px",
                },
            },
        },
        yaxis: {
            axisBorder: {
                show: false,
            },
            axisTicks: {
                show: false,
            },
            labels: {
                style: {
                    colors: "#6b7280",
                    fontSize: "12px",
                },
            },
        },
        fill: {
            opacity: 1,
        },
        tooltip: {
            theme: "light",
            y: {
                formatter: (val: number) => val + " oportunidades",
            },
        },
        legend: {
            position: "bottom" as const,
            horizontalAlign: "center" as const,
            fontSize: "12px",
            markers: {
                size: 4,
            },
        },
        colors: ["#10b981", "#ef4444"],
        grid: {
            borderColor: "#f1f5f9",
            strokeDashArray: 3,
        },
    }

    const barChartSeries = [
        {
            name: "Ganadas",
            data: monthlyData.map((item) => item.ganadas),
        },
        {
            name: "Perdidas",
            data: monthlyData.map((item) => item.perdidas),
        },
    ]

    // Modificar la función combinedChannelData para depurar mejor y asegurar que los datos se procesen correctamente
    console.log("Raw monthlySourceData:", channelData.monthlySourceData)
    console.log("Raw monthlySocialData:", channelData.monthlySocialData)

    // // Reemplazar la lógica de combinedChannelData con una versión más simple y directa
    // const combinedChannelData = []

    // // Procesar monthlySourceData
    // if (Array.isArray(channelData.monthlySourceData)) {
    //     channelData.monthlySourceData.forEach((item) => {
    //         if (item && item.source && item.leads) {
    //             combinedChannelData.push({
    //                 name: item.source,
    //                 value: Number.parseInt(item.leads) || 0,
    //             })
    //         }
    //     })
    // }

    // // Procesar monthlySocialData
    // if (Array.isArray(channelData.monthlySocialData)) {
    //     channelData.monthlySocialData.forEach((item) => {
    //         if (item && (item.social || item.platform) && item.leads) {
    //             combinedChannelData.push({
    //                 name: item.social || item.platform,
    //                 value: Number.parseInt(item.leads) || 0,
    //             })
    //         }
    //     })
    // }

    // console.log("Processed combinedChannelData:", combinedChannelData)

    // // Usar datos de ejemplo si no hay datos reales
    // const finalChartData = combinedChannelData.length > 0 ? combinedChannelData : channelDataExample

    // // Configuración para el gráfico de dona (Canales)
    // const donutChartOptions = {
    //     chart: {
    //         type: "donut" as const,
    //         height: 300,
    //     },
    //     labels: finalChartData.map((item) => item.name),
    //     colors: ["#10b981", "#f59e0b", "#8b5cf6", "#ef4444", "#6b7280", "#3b82f6", "#ec4899"],
    //     plotOptions: {
    //         pie: {
    //             donut: {
    //                 size: "60%",
    //             },
    //         },
    //     },
    //     dataLabels: {
    //         enabled: false,
    //     },
    //     tooltip: {
    //         theme: "light",
    //         y: {
    //             formatter: (val: number) => val + " leads",
    //         },
    //     },
    //     legend: {
    //         position: "bottom" as const,
    //         horizontalAlign: "center" as const,
    //         fontSize: "12px",
    //         markers: {
    //             size: 4,
    //         },
    //     },
    //     responsive: [
    //         {
    //             breakpoint: 480,
    //             options: {
    //                 chart: {
    //                     width: 200,
    //                 },
    //                 legend: {
    //                     position: "bottom" as const,
    //                 },
    //             },
    //         },
    //     ],
    // }

    //const donutChartSeries = finalChartData.map((item: any) => item.value)

    useEffect(() => {
        async function fetchStatistics() {
            if (!session?.user?.accessToken) return

            setLoading(true)
            try {
                const res = await fetch(`${STATISTICS_CRM_DASHBOARD_ENDPOINT}?timeframe=${timeframe}`, {
                    headers: {
                        Authorization: `Bearer ${session?.user?.accessToken}`,
                    },
                })

                if (!res.ok) {
                    console.error("Error fetching statistics:", res.status, res.statusText)
                    return
                }

                const response = await res.json()
                console.log("API Response:", response) // 🔍 Para debug

                // ✅ Usar la estructura correcta del JSON
                if (response.statsCard) {
                    setData(response.statsCard)
                }
            } catch (error) {
                console.error("Error fetching statistics:", error)
            } finally {
                setLoading(false)
            }
        }

        fetchStatistics()
    }, [session, timeframe])

    useEffect(() => {
        async function fetchChannelStatistics() {
            if (!session?.user?.accessToken) return

            try {
                const res = await fetch(`${STATISTICS_CRM_DASHBOARD_ENDPOINT}?timeframe=${timeframe}`, {
                    headers: {
                        Authorization: `Bearer ${session?.user?.accessToken}`,
                    },
                })

                if (!res.ok) {
                    console.error("Error fetching channel statistics:", res.status, res.statusText)
                    return
                }

                const response = await res.json()
                console.log("Channel API Response:", response) // 🔍 Para debug

                setChannelData(response)
            } catch (error) {
                console.error("Error fetching channel statistics:", error)
            }
        }

        fetchChannelStatistics()
    }, [session, timeframe])

    // ✅ Función para calcular la tasa de conversión
    const calculateConversionRate = () => {
        if (data.casesCreated === 0) return "0"
        return ((data.casesWon / data.casesCreated) * 100).toFixed(1)
    }

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="mx-auto space-y-6">
                {/* Header con filtros */}
                <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900">Reporte de Ventas</h1>
                        <p className="text-gray-600">Dashboard de oportunidades y conversiones</p>
                    </div>

                    <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                        <select
                            value={timeframe} // ✅ Corregido: usar timeframe en lugar de timeFilter
                            onChange={(e) => setTimeframe(e.target.value)}
                            className="w-[180px] rounded border border-gray-300 bg-white px-3 py-2 text-sm text-gray-700 focus:border-emerald-500 focus:outline-none"
                        >
                            <option value="day">Hoy</option>
                            <option value="month">Este Mes</option>
                            <option value="year">Este Año</option>
                        </select>

                        <select
                            value={yearFilter}
                            onChange={(e) => setYearFilter(e.target.value)}
                            className="w-[120px] rounded border border-gray-300 bg-white px-3 py-2 text-sm text-gray-700 focus:border-emerald-500 focus:outline-none"
                        >
                            <option value="2024">2024</option>
                            <option value="2023">2023</option>
                            <option value="2022">2022</option>
                        </select>
                    </div>
                </div>

                {/* Indicador de carga */}
                {loading && (
                    <div className="text-center py-4">
                        <p className="text-gray-600">Cargando datos...</p>
                    </div>
                )}

                {/* Métricas principales */}
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                    <Card className="border-l-4 border-l-emerald-500">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium text-gray-600">Total Oportunidades</CardTitle>
                            <Target className="h-4 w-4 text-emerald-600" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold text-gray-900">{data.casesCreated}</div>
                            <p className="text-xs text-emerald-600">
                                <TrendingUp className="mr-1 inline h-3 w-3" />
                                {data.tendenciaCreadas > 0 ? "+" : ""}
                                {data.tendenciaCreadas}% vs período anterior
                            </p>
                        </CardContent>
                    </Card>

                    <Card className="border-l-4 border-l-green-500">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium text-gray-600">Ganadas</CardTitle>
                            <TrendingUp className="h-4 w-4 text-green-600" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold text-gray-900">{data.casesWon}</div>
                            <p className="text-xs text-green-600">
                                <TrendingUp className="mr-1 inline h-3 w-3" />
                                {data.tendenciaGanadas > 0 ? "+" : ""}
                                {data.tendenciaGanadas}% vs período anterior
                            </p>
                        </CardContent>
                    </Card>

                    <Card className="border-l-4 border-l-red-500">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium text-gray-600">Perdidas</CardTitle>
                            <TrendingDown className="h-4 w-4 text-red-600" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold text-gray-900">{data.casesLost}</div>
                            <p className="text-xs text-red-600">
                                <TrendingDown className="mr-1 inline h-3 w-3" />
                                {data.tendenciaPerdidas > 0 ? "+" : ""}
                                {data.tendenciaPerdidas}% vs período anterior
                            </p>
                        </CardContent>
                    </Card>

                    <Card className="border-l-4 border-l-amber-500">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium text-gray-600">En Progreso</CardTitle>
                            <Clock className="h-4 w-4 text-amber-600" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold text-gray-900">{data.casesInProgress}</div>
                            <p className="text-xs text-amber-600">
                                <Clock className="mr-1 inline h-3 w-3" />
                                {data.casesCreated > 0 ? Math.round((data.casesInProgress / data.casesCreated) * 100) : 0}% del total
                            </p>
                        </CardContent>
                    </Card>
                </div>

                {/* Gráficos */}
                <div className="grid gap-6 lg:grid-cols-2">
                    {/* Gráfico de Ganadas vs Perdidas */}
                    <Card>
                        <CardHeader>
                            <CardTitle>Oportunidades Ganadas vs Perdidas</CardTitle>
                            <CardDescription>Comparación mensual de resultados</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="h-[300px]">
                                <Chart options={barChartOptions} series={barChartSeries} type="bar" height={300} />
                            </div>
                        </CardContent>
                    </Card>

                    {/* Gráfico por Canal de Ingreso */}
                    <Card>
                        <CardHeader>
                            <CardTitle>Oportunidades por Canal</CardTitle>
                            <CardDescription>Distribución de leads por fuente de ingreso</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="h-[300px]">
                                {/* {finalChartData.length > 0 ? (
                                    <Chart options={donutChartOptions} series={donutChartSeries} type="donut" height={300} />
                                ) : (
                                    <div className="flex items-center justify-center h-full text-gray-500">
                                        <p>No hay datos disponibles para mostrar</p>
                                    </div>
                                )} */}
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Resumen adicional */}
                <Card>
                    <CardHeader>
                        <CardTitle>Resumen del Período</CardTitle>
                        <CardDescription>Métricas clave de rendimiento</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="grid gap-4 md:grid-cols-3">
                            <div className="flex items-center justify-between rounded-lg border p-4">
                                <div>
                                    <p className="text-sm text-gray-600">Tasa de Conversión</p>
                                    <p className="text-2xl font-bold text-green-600">{calculateConversionRate()}%</p>
                                </div>
                                <Badge variant="light" className="bg-green-100 text-green-800">
                                    {Number.parseFloat(calculateConversionRate()) > 15
                                        ? "Excelente"
                                        : Number.parseFloat(calculateConversionRate()) > 10
                                            ? "Bueno"
                                            : "Regular"}
                                </Badge>
                            </div>

                            <div className="flex items-center justify-between rounded-lg border p-4">
                                <div>
                                    <p className="text-sm text-gray-600">Tiempo Promedio</p>
                                    <p className="text-2xl font-bold text-amber-600">23 días</p>
                                </div>
                                <Badge variant="light" className="bg-amber-100 text-amber-800">
                                    Normal
                                </Badge>
                            </div>

                            <div className="flex items-center justify-between rounded-lg border p-4">
                                <div>
                                    <p className="text-sm text-gray-600">Valor Promedio</p>
                                    <p className="text-2xl font-bold text-emerald-600">$12,450</p>
                                </div>
                                <Badge variant="light" className="bg-emerald-100 text-emerald-800">
                                    Alto
                                </Badge>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    )
}

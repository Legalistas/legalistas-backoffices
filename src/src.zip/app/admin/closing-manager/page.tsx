export default function ClosingManagerPage() {
    return <>Estamos trabajando</>
}
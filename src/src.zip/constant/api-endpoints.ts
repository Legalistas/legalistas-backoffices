export const BASE_URL = `${process.env.NEXT_PUBLIC_BACKEND_URL}`;
export const API_BASE_URL = `${process.env.NEXT_PUBLIC_BACKEND_URL_API}`;

// Authentication Endpoints
export const LOGIN_ENDPOINT = `${API_BASE_URL}/auth/login`;
export const REGISTER_ENDPOINT = `${API_BASE_URL}/auth/register`;
export const LOGOUT_ENDPOINT = `${API_BASE_URL}/auth/logout`;
export const FORGOT_PASSWORD_ENDPOINT = `${API_BASE_URL}/auth/forgot-password`;

// LEGAL CASES
export const CASES_ENDPOINT = `${API_BASE_URL}/cases`;
export const CASES_NOTES_CREATE_ENDPOINT = (caseId: number) =>
  `${API_BASE_URL}/cases/${caseId}/notes`;
export const CASES_NOTES_DELETE_ENDPOINT = (caseId: number, noteId: number) =>
  `${API_BASE_URL}/cases/${caseId}/notes/${noteId}`;

export const CASES_FILES_BY_CASE_ID_ENDPOINT = (
  caseId: number,
  fileId: number
) => `${API_BASE_URL}/cases/${caseId}/files/${fileId}`;

export const CASES_FILES_DELETE_BY_CASE_ID_ENDPOINT = (
  caseId: number,
  fileId: number
) => `${API_BASE_URL}/cases/${caseId}/files/${fileId}`;

export const CASES_FILES_MOVEMENTS_CREATE_ENDPOINT = (
  caseId: number,
  fileId: number
) => `${API_BASE_URL}/cases/${caseId}/files/${fileId}/movements`;

export const CASES_FILES_PARTS_CREATE_ENDPOINT = (
  caseId: number,
  fileId: number
) => `${API_BASE_URL}/cases/${caseId}/files/${fileId}/parts`;
export const CASES_FILES_PARTS_UPDATE_ENDPOINT = (
  caseId: number,
  fileId: number,
  partId: number
) => `${API_BASE_URL}/cases/${caseId}/files/${fileId}/parts/${partId}`;
export const CASES_FILES_PARTS_DELETE_ENDPOINT = (
  caseId: number,
  fileId: number,
  partId: number
) => `${API_BASE_URL}/cases/${caseId}/files/${fileId}/parts/${partId}`;

export const CASES_FILES_NOTES_CREATE_ENDPOINT = (
  caseId: number,
  fileId: number
) => `${API_BASE_URL}/cases/${caseId}/files/${fileId}/notes`;

export const CASES_FILES_NOTES_DELETE_ENDPOINT = (
  caseId: number,
  fileId: number,
  noteId: number
) => `${API_BASE_URL}/cases/${caseId}/files/${fileId}/notes/${noteId}`;

// USERS
export const USERS_ENDPOINT = `${API_BASE_URL}/users`;
export const LAWYERS_ENDPOINT = `${API_BASE_URL}/users/lawyers`;
export const SELLERS_ENDPOINT = `${API_BASE_URL}/users/sellers`;

export const USER_PROFILE_ENDPOINT = `${API_BASE_URL}/users/profile`;
export const USER_NOTIFICATIONS_MARK_ALL_READ_ENDPOINT = (userId: number) =>
  `${API_BASE_URL}/users/${userId}/notifications/read`;

// CRM ENDPOINTS
export const LEADS_ENDPOINT = `${API_BASE_URL}/crm/leads`;

export const LEADS_NOTES_ENDPOINT = (leadId: number) =>
  `${API_BASE_URL}/crm/leads/${leadId}/note`;
export const LEADS_UPLOAD_ENDPOINT = (leadId: number) =>
  `${API_BASE_URL}/crm/leads/${leadId}/documents`;
export const LEADS_DOCUMENTS_DELETE_ENDPOINT = (
  leadId: number,
  documentId: number
) => `${API_BASE_URL}/crm/leads/${leadId}/documents/${documentId}`;

export const STATISTICS_CRM_DASHBOARD_ENDPOINT = `${API_BASE_URL}/statistics/crm-overview`;
export const STATISTICS_CRM_DASHBOARD_SC_ENDPOINT = `${API_BASE_URL}/statistics/crm-source-channel`;
export const STATISTICS_CRM_DASHBOARD_STATES_ENDPOINT = `${API_BASE_URL}/statistics/crm-states`;

export const STATISTICS_LAW_DASHBOARD_ENDPOINT = `${API_BASE_URL}/statistics/causes-overview`;

// UPLOAD ENDPOINTS
export const SETTINGS_JURISDICTIONS_ENDPOINT = `${API_BASE_URL}/settings/jurisdictions`;
export const UPLOAD_ENDPOINT = `${API_BASE_URL}/upload`;
export const SETTINGS_HOLIDAY_ENDPOINT = `${API_BASE_URL}/settings/holidays`;
export const SETTINGS_COUNTRIES_ENDPOINT = `${API_BASE_URL}/settings/countries`;
export const SETTINGS_ROLES_ENDPOINT = `${API_BASE_URL}/settings/roles`;

// CHAT ENDPOINTS
export const CHAT_MESSAGES_ENDPOINT = `${API_BASE_URL}/chat/messages`;
export const CHAT_RECENT_ENDPOINT = `${API_BASE_URL}/chat/recent`;
export const CHAT_HISTORY_ENDPOINT = (userId: number) =>
  `${API_BASE_URL}/chat/messages/${userId}`;
export const CHAT_READ_ENDPOINT = (userId: number) =>
  `${API_BASE_URL}/chat/messages/${userId}/read`;

export const CALENDARS_EVENTS_ENDPOINT = `${API_BASE_URL}/calendar`;

export const NOTIFICATIONS_ENDPOINT = (userId: number) =>
  `${API_BASE_URL}/notifications/${userId}`;
export const NOTIFICATIONS_READ_ENDPOINT = (notificationId: number) =>
  `${API_BASE_URL}/notifications/${notificationId}/read`;
